//! GF(p) — Prime Field Arithmetic
//!
//! Arithmetic over prime fields GF(p) using a const-generic representation.
//! The public API is uniform — `new()` converts any `u64` into a canonical
//! field element, `value()` extracts the canonical `[0, P)` representative,
//! and the `+ − * /` operators and `inv()` all work as expected — but the
//! internal storage form is chosen at compile time based on the algebraic
//! shape of `P`:
//!
//! - **Montgomery form** (`aR mod P` with `R = 2^64`) for generic primes.
//!   Multiplication uses REDC; `new()` and `value()` pay the cost of the
//!   `to_mont` / `from_mont` conversions.
//! - **Canonical form** (value in `[0, P)`) for primes with recognised
//!   structure: Mersenne `2^n − 1` with `n ≥ 31` and Proth `k·2^n + 1`
//!   with `n ≥ 24`. These use the specialised reducers in
//!   [`specialized`]; `new()`/`value()` are essentially the identity
//!   (modulo a single `%`), so short-lived values pay no boundary cost.
//!
//! The switch is made by the compile-time `use_specialized_storage`
//! helper below; callers see a single consistent API regardless of which
//! form the underlying `u64` carries.
//!
//! `P = 2` is handled specially with naive bitwise arithmetic since
//! Montgomery form requires an odd modulus (`gcd(P, R) = 1`).
//!
//! The Goldilocks prime `2^64 − 2^32 + 1` does not fit the `P ≤ 2^63`
//! bound enforced by `Fp<P>` and is exposed via the dedicated
//! [`specialized::GoldilocksFp`] type.
//!
//! # Examples
//!
//! ```
//! use gf2_core::gfp::Fp;
//! use gf2_core::field::{FiniteField, ConstField, FiniteFieldExt};
//!
//! // GF(7): integers {0, 1, 2, 3, 4, 5, 6} with arithmetic mod 7
//! let a = Fp::<7>::new(3);
//! let b = Fp::<7>::new(5);
//!
//! // Addition: (3 + 5) mod 7 = 1
//! assert_eq!(a + b, Fp::<7>::new(1));
//!
//! // Multiplication: (3 * 5) mod 7 = 1, so 3 and 5 are inverses
//! assert_eq!(a * b, Fp::<7>::new(1));
//! assert_eq!(a.inv(), Some(b));
//!
//! // ConstField provides zero-argument constructors
//! assert!(Fp::<7>::zero().is_zero());
//! assert!(Fp::<7>::one().is_one());
//! ```

mod montgomery;
pub mod simd_ops;
pub mod specialized;

pub use simd_ops::SimdVecOps;

use montgomery::{from_mont, mod_pow_mont, mont_add, mont_sub, redc, to_mont, MontConsts};
use specialized::{
    canonical_add, canonical_sub, classify, mersenne_reduce, mersenne_reduce_u64, proth_reduce_u64,
    PrimeShape,
};

use std::fmt;
use std::ops::{Add, AddAssign, Div, Mul, Neg, Sub};

use crate::field::{ConstField, FiniteField, PlePanelLane};

/// Compile-time flag indicating whether `Fp<P>` should use canonical storage
/// with a specialized reduction instead of Montgomery form.
///
/// Evaluated at compile time from the [`classify`] result; `true` only for
/// primes whose specialized reduction beats the `to_mont`/`redc`/`from_mont`
/// round-trip. For generic primes (and for small primes such as `P = 2` or
/// `P = 65537` where Montgomery is already competitive) this is `false`.
const fn use_specialized_storage(p: u64) -> bool {
    if p == 2 {
        return false;
    }
    match classify(p) {
        PrimeShape::Mersenne { n } => n >= 31,
        // Proth primes with n >= 24 benefit because the divisor fits in
        // ≲ 40 bits and the 128-bit `%` path avoids Montgomery's three
        // multiplies. The threshold also covers the BabyBear (n=27) and
        // KoalaBear (n=24) zk-friendly primes.
        PrimeShape::Proth { n, .. } => n >= 24,
        // Goldilocks is handled by the dedicated `GoldilocksFp` type.
        PrimeShape::Goldilocks => false,
        PrimeShape::Generic => false,
    }
}

/// An element of the prime field GF(P) for a compile-time-known prime `P`.
///
/// The public API operates on canonical values in `[0, P)`. The internal
/// storage form is chosen at compile time via [`use_specialized_storage`]:
///
/// - **Canonical form** (value in `[0, P)`) for specialised Mersenne
///   (`n ≥ 31`) and Proth (`n ≥ 24`) primes. `new`/`value` are essentially
///   the identity (one `%`), and multiplication dispatches into the
///   specialised reducers in [`specialized`].
/// - **Montgomery form** (`aR mod P` with `R = 2^64`) for all other
///   primes with `P > 2`. `new`/`value` perform `to_mont`/`from_mont`;
///   multiplication uses REDC.
/// - **Bitwise form** for `P = 2`: multiplication is `&`, addition is
///   `^` — Montgomery is inapplicable because `P` must be odd.
///
/// This is invisible at the API surface: callers always see canonical
/// values and a single set of operators.
///
/// The type parameter `P` must be prime with `1 < P <= 2^63`; primality is not
/// checked at compile time but is required for correctness.
///
/// # Examples
///
/// ```
/// use gf2_core::gfp::Fp;
/// use gf2_core::field::{FiniteField, FiniteFieldExt};
///
/// let a = Fp::<5>::new(3);
/// let b = Fp::<5>::new(4);
///
/// // Fermat's little theorem: a^(p-1) = 1 for non-zero a
/// assert!(a.pow(4).is_one());
///
/// // Additive inverse: -3 mod 5 = 2
/// assert_eq!(-a, Fp::<5>::new(2));
/// ```
///
/// # Panics
///
/// Construction panics (via const assertion) if `P < 2` or `P > 2^63`.
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct Fp<const P: u64>(u64);

impl<const P: u64> fmt::Debug for Fp<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Fp<{}>({})", P, self.value())
    }
}

impl<const P: u64> Fp<P> {
    /// Compile-time validation that P is valid.
    const VALIDATED: () = {
        assert!(P > 1, "Fp<P>: P must be > 1");
        assert!(
            P <= (1u64 << 63),
            "Fp<P>: P must be <= 2^63 for overflow-safe addition"
        );
    };

    /// Creates a new element from a representative value, reduced modulo `P`.
    ///
    /// # Arguments
    ///
    /// * `value` - Any `u64`; will be reduced to `[0, P)`.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::gfp::Fp;
    ///
    /// let a = Fp::<7>::new(10); // 10 mod 7 = 3
    /// assert_eq!(a.value(), 3);
    /// ```
    #[inline]
    pub const fn new(value: u64) -> Self {
        #[allow(clippy::let_unit_value)]
        let _ = Self::VALIDATED;
        let reduced = value % P;
        // Canonical storage (for `P = 2` and for specialized primes) keeps
        // the reduced value as-is; Montgomery storage converts via `to_mont`.
        if P == 2 || use_specialized_storage(P) {
            Self(reduced)
        } else {
            Self(to_mont::<P>(reduced))
        }
    }

    /// Returns the inner representative value in `[0, P)`.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::gfp::Fp;
    ///
    /// assert_eq!(Fp::<7>::new(3).value(), 3);
    /// ```
    #[inline]
    pub const fn value(self) -> u64 {
        if P == 2 || use_specialized_storage(P) {
            self.0
        } else {
            from_mont::<P>(self.0)
        }
    }

    /// Returns the raw internal storage word.
    ///
    /// For primes where [`use_specialized_storage`] is `true` or for
    /// `P = 2`, the internal word already holds the canonical value
    /// in `[0, P)`. For Montgomery-stored primes the word holds
    /// `a · R mod P` — which coincides with the canonical value only
    /// when `R ≡ 1 (mod P)` (for instance `P = 65537`, since
    /// `R = 2^64 ≡ 1 (mod P)`).
    ///
    /// This is a `pub(crate)` backdoor that callers in specialised
    /// SIMD dispatch paths use to avoid the redundant REDC round-trip
    /// in `.value()` for those specific primes. Do **not** use this
    /// outside the crate: the storage form is an implementation detail
    /// and is free to change.
    #[inline]
    #[allow(dead_code)]
    pub(crate) const fn raw_storage(self) -> u64 {
        self.0
    }

    /// Constructs an `Fp<P>` directly from a raw storage word.
    ///
    /// The caller asserts that `raw` is already in the correct internal
    /// representation (canonical for specialised primes and `P = 2`;
    /// Montgomery for everything else). See [`Self::raw_storage`] for
    /// the legality of using a canonical value as Montgomery storage
    /// when `R ≡ 1 (mod P)` (e.g. `P = 65537`).
    ///
    /// Misuse produces silently wrong arithmetic; this helper is
    /// crate-private and exists only for the SIMD dispatch layer.
    #[inline]
    #[allow(dead_code)]
    pub(crate) const fn from_raw_storage(raw: u64) -> Self {
        Self(raw)
    }
}

/// Compile-time helper that performs a specialized modular multiplication
/// when `P` has a recognised structure. Only called from code paths guarded
/// by `use_specialized_storage(P) == true`.
#[inline(always)]
fn specialized_mul<const P: u64>(a: u64, b: u64) -> u64 {
    match classify(P) {
        PrimeShape::Mersenne { n } => {
            // Dispatch on the (compile-time) exponent so the reducer sees
            // a concrete const-generic `N`.
            dispatch_mersenne_mul(n, a, b)
        }
        PrimeShape::Proth { k, n } => dispatch_proth_mul(k, n, a, b),
        PrimeShape::Goldilocks | PrimeShape::Generic => {
            // Unreachable when use_specialized_storage(P) is true; kept as a
            // safety fallback that still produces correct results.
            ((a as u128 * b as u128) % P as u128) as u64
        }
    }
}

/// Dispatch a Mersenne multiplication to the appropriate const-generic
/// instantiation of `mersenne_reduce`. Each arm is monomorphised separately
/// so the `N` is a true compile-time constant inside the reducer.
#[inline(always)]
fn dispatch_mersenne_mul(n: u32, a: u64, b: u64) -> u64 {
    match n {
        // For N ≤ 31 the product fits in u64 so we skip u128 entirely
        // — a 64×64→64 multiply plus a 64-bit fold beats the generic path.
        31 => mersenne_reduce_u64::<31>(a.wrapping_mul(b)),
        // For N = 61 the product is 122 bits; the u128 reducer is optimal.
        61 => mersenne_reduce::<61>((a as u128) * (b as u128)),
        // Other Mersenne exponents are theoretically supported but not
        // specialised here; fall back to generic reduction.
        _ => {
            let wide = (a as u128) * (b as u128);
            (wide % ((1u128 << n) - 1)) as u64
        }
    }
}

#[inline(always)]
fn dispatch_proth_mul(k: u64, n: u32, a: u64, b: u64) -> u64 {
    // For Proth primes P < 2^32 (such as BabyBear and KoalaBear), the
    // product a*b fits in u64 and we can avoid u128 entirely. A u64
    // modulo by a compile-time-known constant compiles to a multiply-high
    // schedule that beats Montgomery REDC's three 64-bit multiplies.
    let p = (k as u128) * (1u128 << n) + 1;
    let p32 = p as u64;
    if p < (1u128 << 32) {
        let prod = a.wrapping_mul(b);
        // For the common cases we hand off to the const-generic reducer;
        // the compiler monomorphises each case separately.
        match (k, n) {
            (15, 27) => proth_reduce_u64::<15, 27>(prod),
            (127, 24) => proth_reduce_u64::<127, 24>(prod),
            _ => prod % p32,
        }
    } else {
        let wide = (a as u128) * (b as u128);
        (wide % p) as u64
    }
}

impl<const P: u64> fmt::Display for Fp<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.value())
    }
}

// ---------------------------------------------------------------------------
// Arithmetic operators
// ---------------------------------------------------------------------------

impl<const P: u64> Add for Fp<P> {
    type Output = Self;

    /// Branchless modular addition.
    ///
    /// Selects between Montgomery-form and canonical-form addition at
    /// compile time based on [`use_specialized_storage`]. Both paths are
    /// identical modular adds on `u64`; the distinction only matters for
    /// consistency with the chosen storage form of `self.0`.
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    fn add(self, rhs: Self) -> Self {
        if use_specialized_storage(P) {
            Self(canonical_add::<P>(self.0, rhs.0))
        } else {
            Self(mont_add::<P>(self.0, rhs.0))
        }
    }
}

impl<const P: u64> Sub for Fp<P> {
    type Output = Self;

    /// Branchless modular subtraction.
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    fn sub(self, rhs: Self) -> Self {
        if use_specialized_storage(P) {
            Self(canonical_sub::<P>(self.0, rhs.0))
        } else {
            Self(mont_sub::<P>(self.0, rhs.0))
        }
    }
}

impl<const P: u64> Mul for Fp<P> {
    type Output = Self;

    /// Modular multiplication.
    ///
    /// Uses specialized reduction for primes with favourable algebraic
    /// structure (Mersenne, Proth), Montgomery REDC otherwise, and bitwise
    /// AND for `P = 2`. The choice is made at compile time — callers see
    /// a single inlined implementation per instantiation.
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    fn mul(self, rhs: Self) -> Self {
        if P == 2 {
            Self(self.0 & rhs.0)
        } else if use_specialized_storage(P) {
            Self(specialized_mul::<P>(self.0, rhs.0))
        } else {
            Self(redc::<P>(self.0 as u128 * rhs.0 as u128))
        }
    }
}

impl<const P: u64> Neg for Fp<P> {
    type Output = Self;

    /// Additive inverse: `-a = P - a` for non-zero, `0` for zero.
    ///
    /// Works identically for both Montgomery and canonical representations.
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    fn neg(self) -> Self {
        if self.0 == 0 {
            self
        } else {
            Self(P - self.0)
        }
    }
}

impl<const P: u64> Div for Fp<P> {
    type Output = Self;

    /// Division via multiplicative inverse.
    ///
    /// # Panics
    ///
    /// Panics if `rhs` is zero.
    ///
    /// # Complexity
    ///
    /// O(log P) (inverse via Fermat's little theorem).
    #[inline]
    #[allow(clippy::suspicious_arithmetic_impl)]
    fn div(self, rhs: Self) -> Self {
        self * rhs.inv().expect("division by zero in Fp")
    }
}

// ---------------------------------------------------------------------------
// AddAssign
// ---------------------------------------------------------------------------

impl<const P: u64> AddAssign for Fp<P> {
    #[inline]
    fn add_assign(&mut self, rhs: Self) {
        *self = *self + rhs;
    }
}

impl<const P: u64> AddAssign<&Self> for Fp<P> {
    #[inline]
    fn add_assign(&mut self, rhs: &Self) {
        *self = *self + *rhs;
    }
}

// ---------------------------------------------------------------------------
// Reference-forwarding operators (Fp is Copy, so dereference and delegate)
// ---------------------------------------------------------------------------

impl<const P: u64> Add<&Fp<P>> for Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn add(self, rhs: &Fp<P>) -> Fp<P> {
        self + *rhs
    }
}

impl<const P: u64> Add for &Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn add(self, rhs: Self) -> Fp<P> {
        *self + *rhs
    }
}

impl<const P: u64> Sub<&Fp<P>> for Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn sub(self, rhs: &Fp<P>) -> Fp<P> {
        self - *rhs
    }
}

impl<const P: u64> Sub for &Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn sub(self, rhs: Self) -> Fp<P> {
        *self - *rhs
    }
}

impl<const P: u64> Mul<&Fp<P>> for Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn mul(self, rhs: &Fp<P>) -> Fp<P> {
        self * *rhs
    }
}

impl<const P: u64> Mul for &Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn mul(self, rhs: Self) -> Fp<P> {
        *self * *rhs
    }
}

impl<const P: u64> Div<&Fp<P>> for Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn div(self, rhs: &Fp<P>) -> Fp<P> {
        self / *rhs
    }
}

impl<const P: u64> Div for &Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn div(self, rhs: Self) -> Fp<P> {
        *self / *rhs
    }
}

impl<const P: u64> Neg for &Fp<P> {
    type Output = Fp<P>;
    #[inline]
    fn neg(self) -> Fp<P> {
        -(*self)
    }
}

// ---------------------------------------------------------------------------
// FiniteField implementation
// ---------------------------------------------------------------------------

impl<const P: u64> FiniteField for Fp<P> {
    type Characteristic = u64;
    type Wide = u128;

    #[inline]
    fn characteristic(&self) -> u64 {
        P
    }

    #[inline]
    fn extension_degree(&self) -> usize {
        1
    }

    #[inline]
    fn is_zero(&self) -> bool {
        self.0 == 0
    }

    #[inline]
    fn is_one(&self) -> bool {
        if P == 2 || use_specialized_storage(P) {
            self.0 == 1
        } else {
            self.0 == MontConsts::<P>::R_MOD_P
        }
    }

    /// Multiplicative inverse via Fermat's little theorem: `a^(P-2) mod P`.
    ///
    /// # Complexity
    ///
    /// O(log P) multiplications.
    fn inv(&self) -> Option<Self> {
        if self.0 == 0 {
            None
        } else if P == 2 {
            Some(Self(1))
        } else if use_specialized_storage(P) {
            // Canonical-form square-and-multiply using specialized_mul.
            let mut result: u64 = 1;
            let mut base: u64 = self.0;
            let mut e = P - 2;
            while e > 0 {
                if e & 1 == 1 {
                    result = specialized_mul::<P>(result, base);
                }
                e >>= 1;
                if e > 0 {
                    base = specialized_mul::<P>(base, base);
                }
            }
            Some(Self(result))
        } else {
            Some(Self(mod_pow_mont::<P>(self.0, P - 2)))
        }
    }

    #[inline]
    fn zero_like(&self) -> Self {
        Self(0)
    }

    #[inline]
    fn one_like(&self) -> Self {
        if P == 2 || use_specialized_storage(P) {
            Self(1)
        } else {
            Self(MontConsts::<P>::R_MOD_P)
        }
    }

    #[inline]
    fn zero_hint() -> Option<Self> {
        Some(Self(0))
    }

    /// Static cardinality hint: `floor(log2(P))`. See
    /// [`FiniteField::cardinality_log2_hint`].
    #[inline]
    fn cardinality_log2_hint() -> Option<u32> {
        // P is a const generic ≥ 2 (validated by `Self::VALIDATED`), so
        // `(u64::BITS - 1) - P.leading_zeros()` is the same as
        // `P.ilog2()` and never panics.
        Some(u64::BITS - 1 - P.leading_zeros())
    }

    #[inline]
    fn to_wide(&self) -> u128 {
        self.value() as u128
    }

    #[inline]
    fn mul_to_wide(&self, rhs: &Self) -> u128 {
        self.value() as u128 * rhs.value() as u128
    }

    /// Storage-domain product for delayed prime-field dot products.
    ///
    /// Bound proof: every `Fp<P>` storage word is in `[0, P)`, both in
    /// canonical form and in Montgomery form (`aR mod P`). Therefore each raw
    /// product is `< (P - 1)^2`, exactly the bound used by
    /// [`FiniteField::max_unreduced_additions`]. A chunk of at most `kmax`
    /// products fits in `u128` without wrapping.
    ///
    /// Representation proof:
    ///
    /// - canonical/specialized storage (`P = 2`, Mersenne, Proth):
    ///   `Σ raw(aᵢ) raw(bᵢ) = Σ aᵢbᵢ`, so reducing modulo `P` is enough.
    /// - Montgomery storage: `raw(a) = aR` and `raw(b) = bR`, hence the chunk
    ///   accumulator is `R² Σ aᵢbᵢ (mod P)`. Reducing it modulo `P` and
    ///   applying one REDC multiplies by `R⁻¹`, yielding `R Σ aᵢbᵢ`, the
    ///   correct Montgomery storage of the dot product.
    ///
    /// This removes two per-product Montgomery-to-canonical conversions from
    /// `FieldVec::dot_product`/`FieldMatrix::gemm`; reduction still happens at
    /// chunk boundaries only.
    #[inline]
    fn mul_product_sum_wide(&self, rhs: &Self) -> u128 {
        self.0 as u128 * rhs.0 as u128
    }

    #[inline]
    fn reduce_wide(wide: &u128) -> Self {
        Self::new((*wide % P as u128) as u64)
    }

    #[inline]
    fn reduce_product_sum_wide(wide: &u128) -> Self {
        let reduced = (*wide % P as u128) as u64;
        if P == 2 || use_specialized_storage(P) {
            Self(reduced)
        } else {
            Self(redc::<P>(reduced as u128))
        }
    }

    /// Routes the dot to the AVX2 16-lane u16 Barrett kernel for
    /// medium primes (`P ∈ (251, 65536)`); other primes return `None` and
    /// the caller continues through the generic delayed-reduction path
    /// driven by [`mul_product_sum_wide`](Self::mul_product_sum_wide).
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_fp_simd_dot_product(
        a: &[Self],
        b: &[Self],
        scratch_a: &mut Vec<u16>,
        scratch_b: &mut Vec<u16>,
    ) -> Option<Self> {
        crate::gfp::simd_ops::fp_medium_try_dot_product::<P>(a, b, scratch_a, scratch_b)
    }

    #[cfg(not(verify_lean))]
    #[inline]
    fn try_pack_fp_medium_u16(xs: &[Self], out: &mut Vec<u16>) -> Option<()> {
        crate::gfp::simd_ops::fp_medium_try_pack_u16::<P>(xs, out)
    }

    #[cfg(not(verify_lean))]
    #[inline]
    fn try_fp_simd_dot_packed_u16(a_packed: &[u16], b_packed: &[u16]) -> Option<Self> {
        crate::gfp::simd_ops::fp_medium_try_dot_packed::<P>(a_packed, b_packed)
    }

    fn max_unreduced_additions() -> usize {
        let max_product = (P as u128 - 1) * (P as u128 - 1);
        if max_product == 0 {
            return usize::MAX;
        }
        let k = u128::MAX / max_product;
        if k > usize::MAX as u128 {
            usize::MAX
        } else {
            k as usize
        }
    }

    /// Theorem-4 per-cell operand bound: `p - 1` for `Fp<P>` with `P > 1`,
    /// and `0` for the degenerate `P = 1` case (which is not a valid
    /// prime — the override is defensive). See
    /// [`FiniteField::theorem_4_operand_bound`] for the semantics.
    #[inline]
    fn theorem_4_operand_bound() -> u128 {
        (P as u128).saturating_sub(1)
    }

    /// Routes the small-prime AVX2 byte-lane dot kernel for
    /// `Fp<P>` with `P ≤ 251`. Returns `None` for primes outside that
    /// range (the chunked-Wide loop in
    /// [`crate::field::vec::dot_product_slices`] handles them
    /// correctly).
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_simd_dot_product(a: &[Self], b: &[Self]) -> Option<Self> {
        <Self as simd_ops::SimdVecOps>::try_simd_dot_vec(a, b)
    }

    /// Whole-gemm small-prime fast path. Pre-packs `a` and `b_t` to
    /// canonical bytes once, calls the AVX2 byte-lane batch-dot
    /// kernel for every output cell against the same packed buffers,
    /// then unpacks. Amortises the Montgomery REDC pack overhead
    /// across the `O(m·k·n)` inner work, eliminating the per-cell
    /// pack thrash that blocks the `dot_product_slices`-level
    /// dispatch from beating scalar at small `n`.
    ///
    /// Two regimes dispatched by `P`:
    /// * `P ≤ 251` — byte-lane Route C / Route A / Candidate C
    ///   (`fp_small_try_gemm_classical`, issue `40195c09`).
    /// * `P ∈ (251, 65535]` — u16-lane panelized GEMM kernel
    ///   (`fp_medium_try_gemm_panel`, issue `74ba1cdc` R1).
    ///
    /// Returns `false` (declining the fast path) when:
    /// - `P > 65535` (out of medium-prime u16-lane range);
    /// - the `simd` feature is disabled;
    /// - AVX2 is unavailable at runtime.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_simd_gemm_classical(
        a: &[Self],
        b_t: &[Self],
        m: usize,
        k: usize,
        n: usize,
        out: &mut [Self],
    ) -> bool {
        // Mersenne31 whole-GEMM: must be checked FIRST because
        // `use_specialized_storage(M31) == true`, which means
        // `fp_small_enabled` and `fp_medium_eligible` both return
        // `false` for P == M31.  Without this guard the call falls
        // through to scalar `dot_product_slices` for every M31 GEMM.
        // Issue `6a7d4c8e`.
        if simd_ops::fp_m31_try_gemm_classical::<P>(a, b_t, m, k, n, out) {
            return true;
        }
        if simd_ops::fp_small_try_gemm_classical::<P>(a, b_t, m, k, n, out) {
            return true;
        }
        simd_ops::fp_medium_try_gemm_panel::<P>(a, b_t, m, k, n, out)
    }

    /// Non-allocating availability probe for the whole-GEMM fast path
    /// (issues `40195c09`, `6a7d4c8e`). Returns `true` when a SIMD
    /// kernel is available for this prime:
    ///
    /// - `P == 2^31 - 1` (Mersenne31): AVX2 `m31_batch_dot_fn`.
    /// - `P ≤ 251`: byte-lane AVX2 (Candidate C / route A / route C).
    /// - `P ∈ (251, 65535]`: u16-lane AVX2 panel kernel.
    ///
    /// Used by [`crate::field::matrix::gemm_axpy_into_view`] to skip
    /// the contiguous-`A` scratch allocation when the kernel will
    /// decline regardless.
    #[cfg(not(verify_lean))]
    #[inline]
    fn has_simd_gemm_classical() -> bool {
        simd_ops::fp_m31_gemm_classical_available::<P>()
            || simd_ops::fp_small_gemm_classical_available::<P>()
    }

    /// Constructs a packed basis reducer for the cyclic-decomposition
    /// reduce loop (issue `d1dd266c`). Returns `None` when no SIMD
    /// fast path is available.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_make_basis_reducer(
        n: usize,
    ) -> Option<Box<dyn crate::field::matrix::BasisReducer<Self>>> {
        simd_ops::fp_try_make_basis_reducer::<P>(n)
    }

    /// Constructs a packed chain-polynomial arithmetic handle for the
    /// `cyclic_decomposition` Krylov-step polynomial bookkeeping
    /// (issue `5a3dbd5b`). Returns `None` when `P > 251` or when AVX2
    /// is unavailable; the caller falls back to the scalar `FieldPoly`
    /// path.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_make_chain_poly_arith(
        n: usize,
    ) -> Option<Box<dyn crate::field::matrix::ChainPolyArith<Self>>> {
        simd_ops::fp_try_make_chain_poly_arith::<P>(n)
    }

    /// Non-allocating availability probe for `try_make_chain_poly_arith`.
    /// Lets `cyclic_decomposition` decide whether to take the packed
    /// canonical-byte chain-poly arithmetic path without paying a boxed
    /// allocation per decomposition.
    #[cfg(not(verify_lean))]
    #[inline]
    fn chain_poly_arith_available() -> bool {
        simd_ops::fp_chain_poly_arith_available::<P>()
    }

    /// SIMD-accelerated `axpy` (`y[i] += a · x[i]`) for `Fp<P>` with
    /// `P ≤ 65521` (issue `d1dd266c`). Routes through the AVX2
    /// byte-lane (`P ≤ 251`) or u16-lane (`252 ≤ P < 65536`)
    /// `batch_mul` + `batch_add` kernels with the scalar `a` broadcast
    /// across the whole vector. Returns `false` for `P > 65535` or
    /// when the `simd` feature / AVX2 are unavailable.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_simd_axpy(y: &mut [Self], a: &Self, x: &[Self]) -> bool {
        simd_ops::fp_try_axpy::<P>(y, a, x)
    }

    /// Whole-matvec fast path for `Fp<P>` with `P ≤ 65521`
    /// (issue `d1dd266c`). Routes through the AVX2 byte-lane batch-dot
    /// kernel for `P ≤ 251` or the u16-lane batch-dot kernel for
    /// `252 ≤ P < 65536`. Pre-packs the matrix and the vector to the
    /// canonical-storage layout used by the kernel; runs one `batch_dot`
    /// per output row; reduces to `Fp<P>` storage.
    ///
    /// Returns `false` for `P > 65535` or when the `simd` feature is
    /// disabled / AVX2 is unavailable, in which case the caller (the
    /// public [`crate::field::matrix::FieldMatrix::matvec`]) falls back
    /// to the per-row scalar `dot_product_slices` chain.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_simd_matvec(a: &[Self], x: &[Self], m: usize, k: usize, out: &mut [Self]) -> bool {
        simd_ops::fp_try_matvec::<P>(a, x, m, k, out)
    }

    /// Pre-packs an `m × k` matrix into the AVX2 canonical-byte
    /// (`P ≤ 251`) or storage-`u16` (`252 ≤ P < 65536`) layout used by
    /// the matvec kernel. Returns `None` when the field is out of range
    /// or the SIMD path is unavailable. Used by the iterative drivers
    /// in [`crate::field::charpoly`] (`cyclic_decomposition`,
    /// `wiedemann_minpoly_attempt`) to amortise the matrix-pack cost
    /// across `O(n)` matvec calls per minpoly / charpoly invocation.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_prepack_matvec(
        a: &[Self],
        m: usize,
        k: usize,
    ) -> Option<Box<dyn crate::field::matrix::PackedMatvec<Self>>> {
        simd_ops::fp_try_prepack_matvec::<P>(a, m, k)
    }

    /// Sparse-times-dense whole-matmat hook. Routes to the AVX2
    /// byte-lane SpMM kernel for `P ≤ 251` (Candidate C small-prime
    /// path) or the AVX2 16-bit-lane SpMM kernel for `P ∈ (251,
    /// 65535]` (medium-prime path). Returns `false` for `P > 65535` or
    /// when the `simd` feature is disabled / AVX2 is unavailable, in
    /// which case the caller falls back to the generic
    /// Wide-accumulator scatter path. The hook packs `b` once
    /// internally and reuses the canonical-byte / canonical-u16 buffer
    /// across every row of the sparse left matrix.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_simd_spmm(
        a_row_ptr: &[usize],
        a_col_idx: &[usize],
        a_values: &[Self],
        b: &[Self],
        b_rows: usize,
        n: usize,
        out: &mut [Self],
    ) -> bool {
        simd_ops::fp_try_spmm::<P>(a_row_ptr, a_col_idx, a_values, b, b_rows, n, out)
    }

    /// Routes to the extension-field scalar Wiedemann minimal-polynomial
    /// path for the supported low-cardinality primes (issue `6c926de0`).
    /// `P ∈ {7, 251}` engages a quadratic or cubic extension large enough
    /// that `|E| > n` for the project's bench sizes (n ≤ 256); other
    /// primes fall through to the default `None`.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_extension_wiedemann_minpoly(
        a: &crate::field::matrix::FieldMatrix<Self>,
    ) -> Option<crate::field::poly::FieldPoly<Self>> {
        crate::field::extension_wiedemann::try_extension_wiedemann_fp::<P>(a)
    }

    /// Panelized PLE base-case fast path for `Fp<P>` (issues `6823c8a0`
    /// + `68db401b`, design `2e8c5a29`).
    ///
    /// Routes by `P`:
    /// * `P <= 251` — AVX2 byte-lane panel kernel via
    ///   [`crate::simd::maybe_fp_small_ple`], row-major axpy Schur
    ///   update over canonical-byte panel rows.
    /// * `252 <= P < 65536` — AVX2 u16-lane panel kernel via
    ///   [`crate::simd::maybe_fp_medium_ple`] (issue `68db401b`),
    ///   row-major axpy Schur update over canonical u16 panel rows
    ///   with widening-to-u32 multiply and the SSOT Barrett reduction.
    /// * Otherwise: returns `None` and the caller falls back to scalar
    ///   `ple_base_direct`.
    #[cfg(not(verify_lean))]
    #[inline]
    fn try_simd_ple_panel_base(
        matrix: &mut [Self],
        parent_cols: usize,
        m: usize,
        col_lo: usize,
        col_hi: usize,
        perm: &mut [usize],
        pivot_cols: &mut Vec<usize>,
    ) -> Option<usize> {
        simd_ops::fp_try_ple_panel_base::<P>(
            matrix,
            parent_cols,
            m,
            col_lo,
            col_hi,
            perm,
            pivot_cols,
        )
    }

    /// Non-allocating lane-class probe for
    /// [`try_simd_ple_panel_base`](Self::try_simd_ple_panel_base).
    /// Returns `Some(PlePanelLane::Byte)` when `P <= 251` and the
    /// small-prime PLE panel kernel is registered, or
    /// `Some(PlePanelLane::U16)` when `252 <= P < 65536` and the
    /// medium-prime PLE panel kernel is registered (issue `68db401b`).
    /// Both require the `simd` feature and runtime-detected AVX2.
    /// Returns `None` otherwise.
    #[cfg(not(verify_lean))]
    #[inline]
    fn simd_ple_panel_lane() -> Option<PlePanelLane> {
        simd_ops::fp_ple_panel_lane::<P>()
    }
}

// ---------------------------------------------------------------------------
// ConstField implementation
// ---------------------------------------------------------------------------

impl<const P: u64> ConstField for Fp<P> {
    #[inline]
    fn zero() -> Self {
        #[allow(clippy::let_unit_value)]
        let _ = Self::VALIDATED;
        Self(0)
    }

    #[inline]
    fn one() -> Self {
        #[allow(clippy::let_unit_value)]
        let _ = Self::VALIDATED;
        if P == 2 || use_specialized_storage(P) {
            Self(1)
        } else {
            Self(MontConsts::<P>::R_MOD_P)
        }
    }

    #[inline]
    fn order() -> u128 {
        P as u128
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::field::{ConstField, FiniteField, FiniteFieldExt};

    // --- Step 1: Construction ---

    #[test]
    fn test_new_reduces_mod_p() {
        assert_eq!(Fp::<7>::new(10).value(), 3);
        assert_eq!(Fp::<7>::new(7).value(), 0);
        assert_eq!(Fp::<7>::new(0).value(), 0);
        assert_eq!(Fp::<7>::new(6).value(), 6);
    }

    #[test]
    fn test_zero_and_one() {
        assert!(Fp::<5>::zero().is_zero());
        assert!(Fp::<5>::one().is_one());
        assert!(!Fp::<5>::zero().is_one());
        assert!(!Fp::<5>::one().is_zero());
    }

    #[test]
    fn test_display() {
        assert_eq!(format!("{}", Fp::<7>::new(5)), "5");
        assert_eq!(format!("{}", Fp::<7>::new(0)), "0");
    }

    // --- Step 2: Basic arithmetic (GF(7)) ---

    #[test]
    fn test_add_gf7() {
        assert_eq!(Fp::<7>::new(3) + Fp::<7>::new(5), Fp::<7>::new(1)); // 8 mod 7
        assert_eq!(Fp::<7>::new(0) + Fp::<7>::new(4), Fp::<7>::new(4));
        assert_eq!(Fp::<7>::new(6) + Fp::<7>::new(6), Fp::<7>::new(5)); // 12 mod 7
    }

    #[test]
    fn test_sub_gf7() {
        assert_eq!(Fp::<7>::new(5) - Fp::<7>::new(3), Fp::<7>::new(2));
        assert_eq!(Fp::<7>::new(3) - Fp::<7>::new(5), Fp::<7>::new(5)); // -2 mod 7
        assert_eq!(Fp::<7>::new(0) - Fp::<7>::new(1), Fp::<7>::new(6));
    }

    #[test]
    fn test_mul_gf7() {
        assert_eq!(Fp::<7>::new(3) * Fp::<7>::new(5), Fp::<7>::new(1)); // 15 mod 7
        assert_eq!(Fp::<7>::new(4) * Fp::<7>::new(0), Fp::<7>::new(0));
        assert_eq!(Fp::<7>::new(6) * Fp::<7>::new(6), Fp::<7>::new(1)); // 36 mod 7
    }

    #[test]
    fn test_neg_gf7() {
        assert_eq!(-Fp::<7>::new(3), Fp::<7>::new(4));
        assert_eq!(-Fp::<7>::new(0), Fp::<7>::new(0));
        assert_eq!(-Fp::<7>::new(1), Fp::<7>::new(6));
    }

    #[test]
    fn test_fp2_is_gf2() {
        type F2 = Fp<2>;
        assert_eq!(F2::new(0) + F2::new(0), F2::new(0));
        assert_eq!(F2::new(1) + F2::new(1), F2::new(0)); // 1+1=0 in char 2
        assert_eq!(F2::new(1) * F2::new(1), F2::new(1));
        assert_eq!(F2::new(1).inv(), Some(F2::new(1)));
    }

    // --- Step 3: Inversion + division ---

    #[test]
    fn test_inv_gf7() {
        assert_eq!(Fp::<7>::new(3).inv(), Some(Fp::<7>::new(5))); // 3 * 5 = 15 ≡ 1
        assert_eq!(Fp::<7>::new(0).inv(), None);
        assert_eq!(Fp::<7>::new(1).inv(), Some(Fp::<7>::new(1)));
    }

    #[test]
    fn test_div_gf7() {
        // 6 / 3 = 6 * inv(3) = 6 * 5 = 30 mod 7 = 2
        assert_eq!(Fp::<7>::new(6) / Fp::<7>::new(3), Fp::<7>::new(2));
    }

    #[test]
    fn test_fermat_little_theorem() {
        for v in 1..7u64 {
            assert!(Fp::<7>::new(v).pow(6).is_one());
        }
    }

    // --- Step 4: Reference ops + AddAssign ---

    #[test]
    #[allow(clippy::op_ref)]
    fn test_ref_operators() {
        let a = Fp::<7>::new(3);
        let b = Fp::<7>::new(5);
        assert_eq!(a + b, Fp::<7>::new(1));
        assert_eq!(&a + &b, Fp::<7>::new(1));
        assert_eq!(a + &b, Fp::<7>::new(1));
        assert_eq!(&a - &b, Fp::<7>::new(5));
        assert_eq!(&a * &b, Fp::<7>::new(1));
        assert_eq!(&a / &b, a * b.inv().unwrap());
        assert_eq!(-&a, Fp::<7>::new(4));
    }

    #[test]
    fn test_add_assign() {
        let mut a = Fp::<7>::new(3);
        a += Fp::<7>::new(5);
        assert_eq!(a, Fp::<7>::new(1));
    }

    #[test]
    fn test_add_assign_ref() {
        let mut a = Fp::<7>::new(3);
        let b = Fp::<7>::new(5);
        a += &b;
        assert_eq!(a, Fp::<7>::new(1));
        assert_eq!(b.value(), 5); // b still valid
    }

    // --- Step 5: FiniteField trait ---

    #[test]
    fn test_characteristic_and_extension() {
        let a = Fp::<5>::new(3);
        assert_eq!(a.characteristic(), 5u64);
        assert_eq!(a.extension_degree(), 1);
    }

    #[test]
    fn test_wide_accumulator() {
        let a = Fp::<7>::new(5);
        let wide = a.to_wide();
        assert_eq!(wide, 5u128);
        let back = Fp::<7>::reduce_wide(&wide);
        assert_eq!(back, a);
    }

    #[test]
    fn test_mul_to_wide() {
        let a = Fp::<7>::new(5);
        let b = Fp::<7>::new(6);
        let wide = a.mul_to_wide(&b);
        assert_eq!(wide, 30u128); // unreduced
        assert_eq!(Fp::<7>::reduce_wide(&wide), Fp::<7>::new(2)); // 30 mod 7
    }

    #[test]
    fn test_storage_domain_product_sum_matches_canonical_dot() {
        fn check<const P: u64>(xs: &[u64], ys: &[u64]) {
            let mut storage_acc = 0u128;
            let mut canonical_acc = 0u128;
            for (&x, &y) in xs.iter().zip(ys.iter()) {
                let a = Fp::<P>::new(x);
                let b = Fp::<P>::new(y);
                storage_acc += a.mul_product_sum_wide(&b);
                canonical_acc += a.mul_to_wide(&b);
            }
            assert_eq!(
                Fp::<P>::reduce_product_sum_wide(&storage_acc),
                Fp::<P>::reduce_wide(&canonical_acc),
                "P={P}"
            );
        }

        let xs = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89];
        let ys = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89];
        check::<2>(&xs, &ys);
        check::<7>(&xs, &ys);
        check::<251>(&xs, &ys);
        check::<65521>(&xs, &ys);
        check::<2_147_483_647>(&xs, &ys);
    }

    #[test]
    fn test_max_unreduced_additions() {
        let k = Fp::<7>::max_unreduced_additions();
        assert!(k > 0);
        let max_product = 6u128 * 6u128;
        assert!(k as u128 <= u128::MAX / max_product);
    }

    #[test]
    fn test_mersenne_61_basic() {
        type M61 = Fp<2305843009213693951>;
        let a = M61::new(123456789);
        let b = M61::new(987654321);
        let sum = a + b;
        assert_eq!(sum.value(), 123456789 + 987654321);

        let inv = a.inv().unwrap();
        assert!((a * inv).is_one());
    }

    // --- Step 6: ConstField ---

    #[test]
    fn test_const_field_order() {
        assert_eq!(Fp::<7>::order(), 7u128);
        assert_eq!(Fp::<65537>::order(), 65537u128);
    }

    // --- Cross-verification: exhaustive for small primes ---

    #[test]
    fn test_montgomery_cross_verify_gf3_exhaustive() {
        for a in 0..3u64 {
            for b in 0..3u64 {
                let fa = Fp::<3>::new(a);
                let fb = Fp::<3>::new(b);
                assert_eq!((fa + fb).value(), (a + b) % 3, "3: {a}+{b}");
                assert_eq!((fa - fb).value(), (a + 3 - b) % 3, "3: {a}-{b}");
                assert_eq!((fa * fb).value(), (a * b) % 3, "3: {a}*{b}");
            }
        }
    }

    #[test]
    fn test_montgomery_cross_verify_gf5_exhaustive() {
        for a in 0..5u64 {
            for b in 0..5u64 {
                let fa = Fp::<5>::new(a);
                let fb = Fp::<5>::new(b);
                assert_eq!((fa + fb).value(), (a + b) % 5, "5: {a}+{b}");
                assert_eq!((fa - fb).value(), (a + 5 - b) % 5, "5: {a}-{b}");
                assert_eq!((fa * fb).value(), (a * b) % 5, "5: {a}*{b}");
            }
            if a > 0 {
                let inv = Fp::<5>::new(a).inv().unwrap();
                assert!((Fp::<5>::new(a) * inv).is_one(), "5: inv({a})");
            }
        }
    }

    #[test]
    fn test_montgomery_cross_verify_gf7_exhaustive() {
        for a in 0..7u64 {
            for b in 0..7u64 {
                let fa = Fp::<7>::new(a);
                let fb = Fp::<7>::new(b);
                assert_eq!((fa + fb).value(), (a + b) % 7, "7: {a}+{b}");
                assert_eq!((fa - fb).value(), (a + 7 - b) % 7, "7: {a}-{b}");
                assert_eq!(
                    (fa * fb).value(),
                    ((a as u128 * b as u128) % 7) as u64,
                    "7: {a}*{b}"
                );
            }
            if a > 0 {
                let inv = Fp::<7>::new(a).inv().unwrap();
                assert!((Fp::<7>::new(a) * inv).is_one(), "7: inv({a})");
                assert_eq!((-Fp::<7>::new(a)).value(), 7 - a, "7: neg({a})");
            }
        }
    }

    // --- Cross-verification: proptest for large primes ---

    mod proptest_cross_verify {
        use super::*;
        use proptest::prelude::*;

        const MERSENNE_61: u64 = (1u64 << 61) - 1;

        // Fp<3>: 2000 cases × 5 ops = 10,000 random ops (also exhaustively
        // covered in test_montgomery_cross_verify_gf3_exhaustive above).
        // Fp<65537>: 2000 cases × 5 ops = 10,000 random ops.
        // Fp<2^61-1>: 2000 cases × 5 ops = 10,000 random ops.
        // Total: 30,000+ verified random operations against naive (a op b) % P.
        proptest! {
            #![proptest_config(proptest::prelude::ProptestConfig::with_cases(2000))]
            #[test]
            fn test_gf3_add(a in 0..3u64, b in 0..3u64) {
                let result = (Fp::<3>::new(a) + Fp::<3>::new(b)).value();
                prop_assert_eq!(result, (a + b) % 3);
            }

            #[test]
            fn test_gf3_sub(a in 0..3u64, b in 0..3u64) {
                let result = (Fp::<3>::new(a) - Fp::<3>::new(b)).value();
                prop_assert_eq!(result, (a + 3 - b) % 3);
            }

            #[test]
            fn test_gf3_mul(a in 0..3u64, b in 0..3u64) {
                let result = (Fp::<3>::new(a) * Fp::<3>::new(b)).value();
                prop_assert_eq!(result, (a * b) % 3);
            }

            #[test]
            fn test_gf3_inv(a in 1..3u64) {
                let fa = Fp::<3>::new(a);
                let inv = fa.inv().unwrap();
                prop_assert!((fa * inv).is_one());
            }

            #[test]
            fn test_gf3_neg(a in 0..3u64) {
                let result = (-Fp::<3>::new(a)).value();
                let expected = if a == 0 { 0 } else { 3 - a };
                prop_assert_eq!(result, expected);
            }

            #[test]
            fn test_gf65537_add(a in 0..65537u64, b in 0..65537u64) {
                let result = (Fp::<65537>::new(a) + Fp::<65537>::new(b)).value();
                prop_assert_eq!(result, (a + b) % 65537);
            }

            #[test]
            fn test_gf65537_sub(a in 0..65537u64, b in 0..65537u64) {
                let result = (Fp::<65537>::new(a) - Fp::<65537>::new(b)).value();
                prop_assert_eq!(result, (a + 65537 - b) % 65537);
            }

            #[test]
            fn test_gf65537_mul(a in 0..65537u64, b in 0..65537u64) {
                let result = (Fp::<65537>::new(a) * Fp::<65537>::new(b)).value();
                let expected = ((a as u128 * b as u128) % 65537) as u64;
                prop_assert_eq!(result, expected);
            }

            #[test]
            fn test_gf65537_inv(a in 1..65537u64) {
                let fa = Fp::<65537>::new(a);
                let inv = fa.inv().unwrap();
                prop_assert!((fa * inv).is_one());
            }

            #[test]
            fn test_gf65537_neg(a in 0..65537u64) {
                let result = (-Fp::<65537>::new(a)).value();
                let expected = if a == 0 { 0 } else { 65537 - a };
                prop_assert_eq!(result, expected);
            }

            #[test]
            fn test_mersenne61_add(a in 0..MERSENNE_61, b in 0..MERSENNE_61) {
                let result = (Fp::<MERSENNE_61>::new(a) + Fp::<MERSENNE_61>::new(b)).value();
                let expected = ((a as u128 + b as u128) % MERSENNE_61 as u128) as u64;
                prop_assert_eq!(result, expected);
            }

            #[test]
            fn test_mersenne61_sub(a in 0..MERSENNE_61, b in 0..MERSENNE_61) {
                let result = (Fp::<MERSENNE_61>::new(a) - Fp::<MERSENNE_61>::new(b)).value();
                let expected = ((a as u128 + MERSENNE_61 as u128 - b as u128) % MERSENNE_61 as u128) as u64;
                prop_assert_eq!(result, expected);
            }

            #[test]
            fn test_mersenne61_mul(a in 0..MERSENNE_61, b in 0..MERSENNE_61) {
                let result = (Fp::<MERSENNE_61>::new(a) * Fp::<MERSENNE_61>::new(b)).value();
                let expected = ((a as u128 * b as u128) % MERSENNE_61 as u128) as u64;
                prop_assert_eq!(result, expected);
            }

            #[test]
            fn test_mersenne61_inv(a in 1..MERSENNE_61) {
                let fa = Fp::<MERSENNE_61>::new(a);
                let inv = fa.inv().unwrap();
                prop_assert!((fa * inv).is_one());
            }

            #[test]
            fn test_mersenne61_neg(a in 0..MERSENNE_61) {
                let result = (-Fp::<MERSENNE_61>::new(a)).value();
                let expected = if a == 0 { 0 } else { MERSENNE_61 - a };
                prop_assert_eq!(result, expected);
            }
        }
    }
}
