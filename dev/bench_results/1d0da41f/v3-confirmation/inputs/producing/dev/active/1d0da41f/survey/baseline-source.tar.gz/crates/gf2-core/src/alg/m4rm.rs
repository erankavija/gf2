//! M4RM (Method of the Four Russians for Multiplication) algorithm.
//!
//! This module implements fast matrix multiplication over GF(2) using the M4RM algorithm.
//! The algorithm processes the multiplication in blocks, precomputing Gray code tables
//! of linear combinations to reduce the number of row operations.
//!
//! When the `simd` feature is enabled, row XOR operations automatically use AVX2
//! vectorization for large matrices, providing significant speedups.
//!
//! # Gray-code table build (kernel B2)
//!
//! [`build_gray_table_flat`] is the B2 hot loop in the M4RM PPC spiral.  The
//! optimized path tiles each table row into 8-word chunks and keeps one running
//! accumulator per chunk, exposing independent XOR chains while preserving the
//! hoisted `XorInplaceFn` dispatch used by the surrounding M4RM row updates.
//!
//! # Schedule selection
//!
//! [`multiply`] resolves the `m4rm` selector family of the active
//! [`crate::tuning::CoreTuning`] once per multiplication and threads the
//! resolved values into the schedule route and the register-tiled C-update
//! gate, so no per-panel or per-row helper reads the profile.
//! [`m4rm_schedule_route`] reports the tier, the Gray-code panel width, and the
//! register-tiled stride gate the dispatcher uses. With no profile installed
//! each field resolves to the conservative default this module's constants
//! define.

use crate::kernels::ops::{resolve_xor_inplace, XorInplaceFn};
use crate::matrix::BitMatrix;
use crate::tuning::M4rmSelectors;
#[cfg(any(test, feature = "test-support"))]
use std::sync::atomic::{AtomicU8, AtomicUsize, Ordering};

/// Column-word tile width for the V2 ILP Gray-table builder.
///
/// Eight `u64` words are 512 bits: enough independent scalar accumulators to
/// break the single-vector dependency chain and a natural size for AVX2 codegen
/// when LLVM batches the XOR/store loops.
const B2_GRAY_TILE_WORDS: usize = 8;
const B2_GRAY_MAX_TILES: usize = 4;

/// Conservative default for `m4rm.default_table_bytes()` in the active
/// [`crate::tuning::CoreTuning`].
///
/// It is the Gray-table byte budget [`production_table_budget`] applies to the
/// narrowest wide-tier strides, where the table stays L1-resident.
pub(crate) const M4RM_DEFAULT_TABLE_BYTES: usize = 64 * 1024;
/// Legacy narrow-tier panel-width cap (pre-jit:bdf60780). Retained as the
/// reference schedule that `test_production_multiply_matches_legacy_schedule_*`
/// compares against on the conservative table; the production small-n path uses
/// [`choose_k_block_small_n`] under `m4rm.small_n_max_k()` instead. No profile
/// field carries it: it is a test fixture, so an installed profile does not
/// move it.
#[cfg_attr(not(test), allow(dead_code))]
const M4RM_DEFAULT_MAX_K: usize = 8;
/// Conservative default for `m4rm.mid_table_bytes()` in the active
/// [`crate::tuning::CoreTuning`].
///
/// It is the Gray-table byte budget [`production_table_budget`] applies to the
/// mid-width band between the default and wide budgets.
pub(crate) const M4RM_MID_TABLE_BYTES: usize = 128 * 1024;
/// Conservative default for `m4rm.wide_table_bytes()` in the active
/// [`crate::tuning::CoreTuning`]: the wider schedule budget for
/// LLC-streaming M4RM rows.
///
/// The production policy keeps rows narrower than the register-tiled threshold
/// on the historical 64 KiB / k≤8 schedule.  At measured 1024+ column rows,
/// same-session measurements for jit:8e305c21 show fewer, wider Gray panels
/// recover the table-build and row-update overhead without letting the table
/// grow beyond the 256 KiB L2 size class that regressed at small widths.
pub(crate) const M4RM_WIDE_TABLE_BYTES: usize = 256 * 1024;
/// Conservative default for `m4rm.wide_max_k()` in the active
/// [`crate::tuning::CoreTuning`].
///
/// It caps the Gray-code panel width the wide tier selects once the byte budget
/// admits a wider one.
pub(crate) const M4RM_WIDE_MAX_K: usize = 9;

/// Row accumulators held by the M4RM C-tile update.
///
/// Kernel shape rather than a host-tuning value — it is the row count of the
/// 8×4 register tile and of `M4rmTile8xNFn`'s index array — so no profile field
/// carries it.
const M4RM_TILE_ROWS: usize = 8;
/// Column words per register tile: four u64 lanes fit exactly in one YMM.
///
/// Kernel shape rather than a host-tuning value, and the floor
/// [`crate::tuning::M4rmSelectors::try_new`] validates
/// `m4rm.tiled_min_stride_words()` against: a narrower stride cannot fire the
/// tile even once.
pub(crate) const M4RM_TILE_WORDS: usize = 4;
/// Conservative default for `m4rm.tiled_min_stride_words()` in the active
/// [`crate::tuning::CoreTuning`]: the minimum row stride (in u64 words) for
/// the register-tiled M4RM C-update.
///
/// The 8×4 YMM tile processes four output words per lane, so it needs at least
/// [`M4RM_TILE_WORDS`] full words to fire even once. The default is defined by
/// naming that constant rather than by restating its value, and the profile
/// field carries the same floor. The four-word gate is measured for
/// jit:bdf60780: at `n=256` (stride 4) the SIMD tile plus the SIMD Gray-table
/// builder beat the scalar row-XOR schedule by ~1.7×
/// (`2026-05-28-bdf60780-matmul-gf2-smalln.md`), closing the M4RI parity gap.
/// Narrower strides (1..=3) fall through to the row-XOR path because there is
/// no full 4-word tile.
pub(crate) const M4RM_TILED_MIN_STRIDE_WORDS: usize = M4RM_TILE_WORDS;
/// Conservative default for `m4rm.small_n_max_k()` in the active
/// [`crate::tuning::CoreTuning`]: the upper bound on the small-`n`
/// (sub-wide-tier) Gray-code panel width.
///
/// Below the wide-row tier the table is L1-resident and the cost-balanced
/// optimum is `~0.8·log2(min(K, n))` panels, not the maximum width the byte
/// budget allows. Capping at 8 keeps the `k=8` panel that wins at `n=256` while
/// the heuristic still selects `k=4..5` at `n=64`.
pub(crate) const M4RM_SMALL_N_MAX_K: usize = 8;
type M4rmTile8xNFn = fn(&mut [u64], usize, &[u64], &[usize; M4RM_TILE_ROWS]);

/// The Gray-code schedule tier [`multiply`] selects for an output width.
///
/// The tier comparison reads `m4rm.wide_tier_min_stride_words()` from the
/// active [`crate::tuning::CoreTuning`]: a row stride at or above that value
/// takes the byte-budgeted wide schedule, anything narrower the L1-resident
/// small-`n` heuristic.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum M4rmScheduleTier {
    /// The L1-resident small-`n` cost-balance heuristic.
    SmallN,
    /// The byte-budgeted wide-row schedule.
    Wide,
}

/// The selector band that supplied an M4RM panel schedule.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum M4rmTableBand {
    /// The small-output heuristic, which does not consume a byte budget.
    SmallN,
    /// The narrow wide-tier band consuming `default_table_bytes`.
    Default,
    /// The middle wide-tier band consuming `mid_table_bytes`.
    Mid,
    /// The widest band consuming `wide_table_bytes`.
    Wide,
}

/// Test-only observation of the effective M4RM C-update selected by [`multiply`].
///
/// This closed observation is evidence instrumentation, not a route selector or
/// forcing mechanism. It is available only to crate tests or with the
/// `test-support` feature and is intended for one public multiplication in a
/// fresh, single-threaded child process. [`None`](Self::None) means no row-wise
/// or register-tiled panel update has been selected since
/// [`reset_m4rm_tiled_effective_observation`].
#[cfg(any(test, feature = "test-support"))]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum M4rmTiledEffectiveObservation {
    /// No panel-update implementation has been selected since the last reset.
    None,
    /// The row-wise panel update is the effective implementation.
    RowWise,
    /// The resolved SIMD register-tiled update is the effective implementation.
    RegisterTiled,
}

#[cfg(any(test, feature = "test-support"))]
static M4RM_TILED_EFFECTIVE_OBSERVATION: AtomicU8 = AtomicU8::new(0);

#[cfg(any(test, feature = "test-support"))]
fn record_m4rm_tiled_effective_observation(observation: M4rmTiledEffectiveObservation) {
    let encoded = match observation {
        M4rmTiledEffectiveObservation::None => 0,
        M4rmTiledEffectiveObservation::RowWise => 1,
        M4rmTiledEffectiveObservation::RegisterTiled => 2,
    };
    M4RM_TILED_EFFECTIVE_OBSERVATION.store(encoded, Ordering::SeqCst);
}

/// Resets the test-only effective M4RM C-update observation to `None`.
///
/// This resets only evidence instrumentation. It does not reset tuning,
/// capability detection, or any production selector.
#[cfg(any(test, feature = "test-support"))]
pub fn reset_m4rm_tiled_effective_observation() {
    M4RM_TILED_EFFECTIVE_OBSERVATION.store(0, Ordering::SeqCst);
}

/// Reads the test-only effective M4RM C-update observation.
///
/// Call this after exactly one [`multiply`] in the fresh child whose call was
/// preceded by [`reset_m4rm_tiled_effective_observation`]. Concurrent
/// multiplications intentionally have no attribution guarantee.
#[cfg(any(test, feature = "test-support"))]
#[must_use]
pub fn m4rm_tiled_effective_observation() -> M4rmTiledEffectiveObservation {
    match M4RM_TILED_EFFECTIVE_OBSERVATION.load(Ordering::SeqCst) {
        0 => M4rmTiledEffectiveObservation::None,
        1 => M4rmTiledEffectiveObservation::RowWise,
        2 => M4rmTiledEffectiveObservation::RegisterTiled,
        value => panic!("invalid effective M4RM C-update observation {value}"),
    }
}

/// One completed production M4RM schedule, including every consumed extent.
///
/// The value is execution evidence published after [`multiply`] returns from
/// its selected C-update. It does not participate in schedule selection.
#[cfg(any(test, feature = "test-support"))]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct M4rmScheduleExecution {
    tier: M4rmScheduleTier,
    table_band: M4rmTableBand,
    table_bytes: Option<usize>,
    panel_width_cap: usize,
    panel_width: usize,
    tiled_stride_admitted: bool,
    c_update: M4rmTiledEffectiveObservation,
}

#[cfg(any(test, feature = "test-support"))]
impl M4rmScheduleExecution {
    /// Returns the executed schedule tier.
    #[must_use]
    pub fn tier(self) -> M4rmScheduleTier {
        self.tier
    }

    /// Returns the selector band that supplied the schedule.
    #[must_use]
    pub fn table_band(self) -> M4rmTableBand {
        self.table_band
    }

    /// Returns the consumed table byte budget, or `None` for `SmallN`.
    #[must_use]
    pub fn table_bytes(self) -> Option<usize> {
        self.table_bytes
    }

    /// Returns the active panel-width cap for the selected tier.
    #[must_use]
    pub fn panel_width_cap(self) -> usize {
        self.panel_width_cap
    }

    /// Returns the panel width consumed by the completed multiplication.
    #[must_use]
    pub fn panel_width(self) -> usize {
        self.panel_width
    }

    /// Returns whether the output stride admitted the register-tiled update.
    #[must_use]
    pub fn tiled_stride_admitted(self) -> bool {
        self.tiled_stride_admitted
    }

    /// Returns the C-update implementation used by the completed operation.
    #[must_use]
    pub fn c_update(self) -> M4rmTiledEffectiveObservation {
        self.c_update
    }
}

/// Test-only observation of a fully completed production M4RM schedule.
#[cfg(any(test, feature = "test-support"))]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum M4rmEffectiveScheduleObservation {
    /// No multiplication has completed since the observation was reset.
    None,
    /// One multiplication completed with the enclosed effective schedule.
    Completed(M4rmScheduleExecution),
}

#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_STATE: AtomicU8 = AtomicU8::new(0);
#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_BAND: AtomicU8 = AtomicU8::new(0);
#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_TABLE_BYTES: AtomicUsize = AtomicUsize::new(0);
#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_PANEL_CAP: AtomicUsize = AtomicUsize::new(0);
#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_PANEL_WIDTH: AtomicUsize = AtomicUsize::new(0);
#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_TILED_ADMITTED: AtomicU8 = AtomicU8::new(0);
#[cfg(any(test, feature = "test-support"))]
static M4RM_EFFECTIVE_SCHEDULE_C_UPDATE: AtomicU8 = AtomicU8::new(0);

#[cfg(any(test, feature = "test-support"))]
fn record_m4rm_effective_schedule(
    route: M4rmScheduleRoute,
    c_update: M4rmTiledEffectiveObservation,
) {
    let band = match route.table_band {
        M4rmTableBand::SmallN => 1,
        M4rmTableBand::Default => 2,
        M4rmTableBand::Mid => 3,
        M4rmTableBand::Wide => 4,
    };
    let c_update = match c_update {
        M4rmTiledEffectiveObservation::None => 0,
        M4rmTiledEffectiveObservation::RowWise => 1,
        M4rmTiledEffectiveObservation::RegisterTiled => 2,
    };
    M4RM_EFFECTIVE_SCHEDULE_BAND.store(band, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_TABLE_BYTES.store(route.table_bytes.unwrap_or(0), Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_PANEL_CAP.store(route.panel_width_cap, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_PANEL_WIDTH.store(route.panel_width, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_TILED_ADMITTED
        .store(u8::from(route.tiled_stride_admitted), Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_C_UPDATE.store(c_update, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_STATE.store(1, Ordering::Release);
}

/// Resets the test-only completed-schedule observation.
///
/// This changes evidence instrumentation only. It does not reset tuning or
/// capability detection. Reset the C-update observation at the same time so a
/// later completed schedule cannot inherit evidence from an earlier call.
#[cfg(any(test, feature = "test-support"))]
pub fn reset_m4rm_effective_schedule_observation() {
    M4RM_EFFECTIVE_SCHEDULE_STATE.store(0, Ordering::Release);
    M4RM_EFFECTIVE_SCHEDULE_BAND.store(0, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_TABLE_BYTES.store(0, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_PANEL_CAP.store(0, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_PANEL_WIDTH.store(0, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_TILED_ADMITTED.store(0, Ordering::Relaxed);
    M4RM_EFFECTIVE_SCHEDULE_C_UPDATE.store(0, Ordering::Relaxed);
    reset_m4rm_tiled_effective_observation();
}

/// Reads the effective schedule of the most recent completed multiplication.
///
/// Call this after exactly one [`multiply`] following
/// [`reset_m4rm_effective_schedule_observation`]. Concurrent multiplications
/// intentionally have no attribution guarantee.
#[cfg(any(test, feature = "test-support"))]
#[must_use]
pub fn m4rm_effective_schedule_observation() -> M4rmEffectiveScheduleObservation {
    if M4RM_EFFECTIVE_SCHEDULE_STATE.load(Ordering::Acquire) == 0 {
        return M4rmEffectiveScheduleObservation::None;
    }
    let table_band = match M4RM_EFFECTIVE_SCHEDULE_BAND.load(Ordering::Relaxed) {
        1 => M4rmTableBand::SmallN,
        2 => M4rmTableBand::Default,
        3 => M4rmTableBand::Mid,
        4 => M4rmTableBand::Wide,
        value => panic!("invalid effective M4RM table-band observation {value}"),
    };
    let c_update = match M4RM_EFFECTIVE_SCHEDULE_C_UPDATE.load(Ordering::Relaxed) {
        0 => M4rmTiledEffectiveObservation::None,
        1 => M4rmTiledEffectiveObservation::RowWise,
        2 => M4rmTiledEffectiveObservation::RegisterTiled,
        value => panic!("invalid effective M4RM C-update observation {value}"),
    };
    M4rmEffectiveScheduleObservation::Completed(M4rmScheduleExecution {
        tier: if table_band == M4rmTableBand::SmallN {
            M4rmScheduleTier::SmallN
        } else {
            M4rmScheduleTier::Wide
        },
        table_band,
        table_bytes: (table_band != M4rmTableBand::SmallN)
            .then(|| M4RM_EFFECTIVE_SCHEDULE_TABLE_BYTES.load(Ordering::Relaxed)),
        panel_width_cap: M4RM_EFFECTIVE_SCHEDULE_PANEL_CAP.load(Ordering::Relaxed),
        panel_width: M4RM_EFFECTIVE_SCHEDULE_PANEL_WIDTH.load(Ordering::Relaxed),
        tiled_stride_admitted: M4RM_EFFECTIVE_SCHEDULE_TILED_ADMITTED.load(Ordering::Relaxed) != 0,
        c_update,
    })
}

/// The tier, Gray-code panel width, and register-tiled stride gate selected for
/// one M4RM multiplication.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct M4rmScheduleRoute {
    tier: M4rmScheduleTier,
    table_band: M4rmTableBand,
    table_bytes: Option<usize>,
    panel_width_cap: usize,
    panel_width: usize,
    tiled_stride_admitted: bool,
}

impl M4rmScheduleRoute {
    /// Returns the selected schedule tier.
    #[must_use]
    pub fn tier(&self) -> M4rmScheduleTier {
        self.tier
    }

    /// Returns the selector band that supplies this schedule.
    #[must_use]
    pub fn table_band(&self) -> M4rmTableBand {
        self.table_band
    }

    /// Returns the selected table byte budget, or `None` for `SmallN`.
    #[must_use]
    pub fn table_bytes(&self) -> Option<usize> {
        self.table_bytes
    }

    /// Returns the active panel-width cap for the selected tier.
    #[must_use]
    pub fn panel_width_cap(&self) -> usize {
        self.panel_width_cap
    }

    /// Returns the selected Gray-code panel width in bits (`k_block`).
    ///
    /// Zero reports a degenerate operand (`k == 0` or `n == 0`); one routes the
    /// multiplication to the row-XOR path instead of a Gray-code panel.
    #[must_use]
    pub fn panel_width(&self) -> usize {
        self.panel_width
    }

    /// Returns whether the output width admits the register-tiled C-update.
    ///
    /// This is the stride half of that schedule's gate, the half
    /// `m4rm.tiled_min_stride_words()` carries. The other half — at least
    /// `M4RM_TILE_ROWS` full rows — is kernel shape and depends on the
    /// operand's row count, which this reporter does not take, so an admitted
    /// stride does not on its own put a multiplication on the tiled schedule.
    #[must_use]
    pub fn tiled_stride_admitted(&self) -> bool {
        self.tiled_stride_admitted
    }
}

/// Reports the M4RM schedule [`multiply`] selects for an inner dimension and an
/// output width.
///
/// The tier comparison reads `m4rm.wide_tier_min_stride_words()`, the panel
/// width reads the three table byte budgets and both panel-width ceilings, and
/// the register-tiled stride gate reads `m4rm.tiled_min_stride_words()`, all
/// from the active [`crate::tuning::CoreTuning`]. [`multiply`] resolves the
/// same family once per call and selects through the same resolved selectors,
/// so this reporter and the dispatcher cannot disagree.
#[must_use]
pub fn m4rm_schedule_route(k: usize, n: usize) -> M4rmScheduleRoute {
    m4rm_schedule_route_resolved(crate::tuning::active().m4rm(), k, n)
}

/// Reports the production M4RM schedule for an explicit selector family.
///
/// Calibration harnesses use this seam to validate a candidate before it is
/// installed globally. It calls the same pure selector logic as [`multiply`]
/// and [`m4rm_schedule_route`].
#[cfg(any(test, feature = "test-support"))]
#[doc(hidden)]
#[must_use]
pub fn m4rm_schedule_route_for_selectors(
    m4rm: &M4rmSelectors,
    k: usize,
    n: usize,
) -> M4rmScheduleRoute {
    m4rm_schedule_route_resolved(m4rm, k, n)
}

/// Reports the M4RM schedule against an already-resolved selector family.
fn m4rm_schedule_route_resolved(m4rm: &M4rmSelectors, k: usize, n: usize) -> M4rmScheduleRoute {
    let stride_words = row_stride_words(n);
    let tier = schedule_tier(m4rm.wide_tier_min_stride_words(), stride_words);
    let (table_band, table_bytes, panel_width_cap, panel_width) = match tier {
        M4rmScheduleTier::SmallN => (
            M4rmTableBand::SmallN,
            None,
            m4rm.small_n_max_k(),
            choose_k_block_small_n(m4rm.small_n_max_k(), k, n),
        ),
        M4rmScheduleTier::Wide => {
            let band = production_table_band(stride_words);
            let bytes = production_table_budget(m4rm, stride_words);
            (
                band,
                Some(bytes),
                m4rm.wide_max_k(),
                choose_k_block_with_limit(k, n, bytes, m4rm.wide_max_k()),
            )
        }
    };
    M4rmScheduleRoute {
        tier,
        table_band,
        table_bytes,
        panel_width_cap,
        panel_width,
        tiled_stride_admitted: stride_admits_tiled_schedule(
            m4rm.tiled_min_stride_words(),
            stride_words,
        ),
    }
}

/// Row stride in u64 words for an output width.
#[inline]
fn row_stride_words(n: usize) -> usize {
    if n == 0 {
        0
    } else {
        n.div_ceil(64)
    }
}

/// Selects the schedule tier for a row stride against an already-resolved
/// `wide_tier_min_stride_words`.
#[inline]
fn schedule_tier(wide_tier_min_stride_words: usize, stride_words: usize) -> M4rmScheduleTier {
    if stride_words >= wide_tier_min_stride_words {
        M4rmScheduleTier::Wide
    } else {
        M4rmScheduleTier::SmallN
    }
}

/// Chooses the Gray-code panel width for one multiplication against an
/// already-resolved selector family.
///
/// The panel width determines the size of the Gray code table (2^k entries).
/// Each table is kept cache-sized by `m4rm.default_table_bytes()`,
/// `m4rm.mid_table_bytes()`, and `m4rm.wide_table_bytes()`, capped by
/// `m4rm.wide_max_k()` in the wide tier and by `m4rm.small_n_max_k()` below it.
///
/// # Arguments
///
/// * `m4rm` - Selector family resolved once by the caller
/// * `k` - Inner dimension (A is m×k, B is k×n)
/// * `n` - Output width (number of columns in result)
///
/// # Returns
///
/// Block size k_block (typically 6-9 on the conservative table)
fn choose_k_block(m4rm: &M4rmSelectors, k: usize, n: usize) -> usize {
    m4rm_schedule_route_resolved(m4rm, k, n).panel_width
}

/// Conservative default for `m4rm.wide_tier_min_stride_words()` in the active
/// [`crate::tuning::CoreTuning`]: the stride threshold (in u64 words) at
/// which the wide-row M4RM schedule applies.
///
/// At and above 16 words (`n >= 1024`) the production policy keeps the
/// register-tiled wide schedule (`8e305c21`/`974a85bd`); below it, the small-`n`
/// L1-resident heuristic in [`choose_k_block_small_n`] selects the panel width.
pub(crate) const M4RM_WIDE_TIER_MIN_STRIDE_WORDS: usize = 16;

/// Selects the Gray-code panel width for the small-`n` (L1-resident) regime
/// against an already-resolved `small_n_max_k`.
///
/// Below the wide tier the whole Gray table fits in L1, so the cost-balanced
/// optimum is governed by the panel count rather than the table byte budget. We
/// use the M4RI cost-balance heuristic `round(0.8 · log2(min(k, n)))`, clamped
/// to `[2, small_n_max_k]` and never above the inner dimension `k`. On the
/// conservative table this reproduces the measured per-size optima
/// (`2026-05-28-bdf60780-matmul-gf2-smalln.md`): `k≈5` at `n=64`, `k≈7` at
/// `n=256`, both comfortably inside the 1.5× M4RI target.
fn choose_k_block_small_n(small_n_max_k: usize, k: usize, n: usize) -> usize {
    if k == 0 || n == 0 {
        return 0;
    }
    if k == 1 {
        return 1;
    }
    // Balance point: ~0.8 * log2(min(k, n)) bits per panel.
    let span = k.min(n) as f64;
    let target = (0.8_f64 * span.log2()).round() as usize;
    target.clamp(2, small_n_max_k).min(k)
}

/// Selects the wide tier's Gray-table byte budget for a row stride against an
/// already-resolved selector family.
///
/// The two band bounds are kernel-adjacent constants that no profile field
/// carries; the budget each band selects is `m4rm.wide_table_bytes()`,
/// `m4rm.mid_table_bytes()`, or `m4rm.default_table_bytes()`.
#[inline]
fn production_table_budget(m4rm: &M4rmSelectors, stride_words: usize) -> usize {
    match production_table_band(stride_words) {
        M4rmTableBand::Wide => m4rm.wide_table_bytes(),
        M4rmTableBand::Mid => m4rm.mid_table_bytes(),
        M4rmTableBand::Default => m4rm.default_table_bytes(),
        M4rmTableBand::SmallN => unreachable!("small-N has no table byte budget"),
    }
}

#[inline]
fn production_table_band(stride_words: usize) -> M4rmTableBand {
    if stride_words >= 64 {
        M4rmTableBand::Wide
    } else if stride_words >= 32 {
        M4rmTableBand::Mid
    } else {
        M4rmTableBand::Default
    }
}

fn choose_k_block_with_limit(
    k: usize,
    n: usize,
    target_table_bytes: usize,
    max_k_block: usize,
) -> usize {
    // Each table entry is a row of n bits, stored in stride_words u64s
    let stride_words = if n == 0 { 0 } else { n.div_ceil(64) };
    let bytes_per_entry = stride_words * 8;

    if k == 0 || max_k_block == 0 {
        return 0;
    }

    let largest_k = max_k_block.min(k).min(usize::BITS as usize - 1);
    if bytes_per_entry == 0 {
        return largest_k;
    }

    let max_table_entries = target_table_bytes / bytes_per_entry;
    for k_block in (1..=largest_k).rev() {
        let table_entries = 1usize << k_block;

        if table_entries <= max_table_entries {
            return k_block;
        }
    }

    // Fallback to smallest block size
    1.min(k)
}

/// Builds a lookup table for all linear combinations of k_block consecutive rows from matrix B.
///
/// Uses Gray code ordering for efficient table generation. Each Gray code step differs
/// by exactly one bit from the previous, requiring only a single XOR operation per entry
/// instead of multiple XORs with binary enumeration.
///
/// table[i] = XOR of rows indicated by the binary representation of i
/// For example, if k_block=3:
///   table[0b000] = zero vector
///   table[0b001] = row 0
///   table[0b010] = row 1
///   table[0b011] = row 0 XOR row 1
///   table[0b100] = row 2
///   ...
///
/// # Arguments
///
/// * `b` - Input matrix B
/// * `row_start` - Starting row index in B
/// * `k_block` - Number of rows to include in the table
/// * `n` - Number of columns in B
///
/// # Returns
///
/// A vector of 2^k_block entries, indexed by binary representation
#[cfg(test)]
fn build_gray_table(b: &BitMatrix, row_start: usize, k_block: usize, n: usize) -> Vec<Vec<u64>> {
    let table_size = 1usize << k_block;
    let stride_words = if n == 0 { 0 } else { n.div_ceil(64) };

    let mut table = vec![vec![0u64; stride_words]; table_size];

    // Use Gray code ordering for efficient table generation
    // Gray code: G(i) = i XOR (i >> 1)
    // Each step differs by exactly one bit, so we only need one XOR per entry

    let mut current = vec![0u64; stride_words];
    let mut prev_gray = 0usize;

    // First entry (all zeros) is already initialized
    table[0].copy_from_slice(&current);

    for i in 1..table_size {
        let curr_gray = i ^ (i >> 1); // Gray code formula

        // Find which bit flipped between previous and current Gray code
        let diff = prev_gray ^ curr_gray;
        let bit_pos = diff.trailing_zeros() as usize;

        // XOR in (or out) the corresponding row
        if row_start + bit_pos < b.rows() {
            let row_words = b.row_words(row_start + bit_pos);
            crate::kernels::ops::xor_inplace(&mut current, row_words);
        }

        // Store in table at the Gray code position
        table[curr_gray].copy_from_slice(&current);

        prev_gray = curr_gray;
    }

    table
}

/// Builds a lookup table into a pre-allocated flat buffer.
///
/// This is a memory-optimized version that writes directly to a flat buffer
/// instead of allocating a Vec<Vec<u64>>. This eliminates allocation overhead
/// when the table is rebuilt multiple times (e.g., for each panel in M4RM).
///
/// Uses Gray code ordering for efficient table generation.
///
/// # Arguments
///
/// * `b` - Input matrix B
/// * `row_start` - Starting row index in B
/// * `k_block` - Number of rows to include in the table
/// * `n` - Number of columns in B
/// * `buffer` - Pre-allocated flat buffer to write table into
///   Must have length >= (2^k_block) * stride_words
/// * `xor` - Pre-resolved row XOR operation for `stride_words`-wide rows
///
/// # Layout
///
/// The buffer stores table entries sequentially:
/// - Entry 0: buffer[0..stride_words]
/// - Entry 1: buffer[stride_words..2*stride_words]
/// - Entry i: buffer[i*stride_words..(i+1)*stride_words]
#[doc(hidden)]
#[inline(never)]
pub fn build_gray_table_flat(
    b: &BitMatrix,
    row_start: usize,
    k_block: usize,
    n: usize,
    buffer: &mut [u64],
    xor: XorInplaceFn,
) {
    let table_size = 1usize << k_block;
    let stride_words = if n == 0 { 0 } else { n.div_ceil(64) };

    if stride_words == 0 || table_size == 0 {
        return;
    }

    debug_assert!(
        buffer.len() >= table_size * stride_words,
        "build_gray_table_flat: buffer too small ({} < {} × {})",
        buffer.len(),
        table_size,
        stride_words
    );

    #[cfg(feature = "simd")]
    if let Some(fns) = crate::simd::maybe_simd() {
        // Full-table SIMD builders for narrow rows: one (stride 4) or two
        // (stride 8) YMM accumulators carry the Gray walk, eliminating the
        // scalar per-word XOR loop that dominated small-n table build time.
        // `k_block` panel rows are all present (panel_size <= b.rows() - row_start),
        // so every flipped bit_pos in [0, k_block) indexes a valid B row.
        if stride_words == 4 && row_start + k_block <= b.rows() {
            let panel = b.row_words_block(row_start, k_block);
            (fns.m4rm_gray_build4_fn)(buffer, panel, stride_words, table_size, k_block);
            return;
        }
        if stride_words == 8 && row_start + k_block <= b.rows() {
            let panel = b.row_words_block(row_start, k_block);
            (fns.m4rm_gray_build8_fn)(buffer, panel, stride_words, table_size, k_block);
            return;
        }
        if stride_words == 2 * B2_GRAY_TILE_WORDS {
            gray_walk_stride16_simd(
                b,
                row_start,
                table_size,
                stride_words,
                buffer,
                fns.m4rm_gray_xor16_fn,
            );
            return;
        }
    }

    if stride_words <= B2_GRAY_MAX_TILES * B2_GRAY_TILE_WORDS {
        let tile_count = stride_words.div_ceil(B2_GRAY_TILE_WORDS);
        let last_tile_words = stride_words - (tile_count - 1) * B2_GRAY_TILE_WORDS;

        match (tile_count, last_tile_words) {
            (1, B2_GRAY_TILE_WORDS) => {
                gray_walk_full::<1>(b, row_start, table_size, stride_words, buffer)
            }
            (2, B2_GRAY_TILE_WORDS) => {
                gray_walk_full::<2>(b, row_start, table_size, stride_words, buffer)
            }
            (3, B2_GRAY_TILE_WORDS) => {
                gray_walk_full::<3>(b, row_start, table_size, stride_words, buffer)
            }
            (4, B2_GRAY_TILE_WORDS) => {
                gray_walk_full::<4>(b, row_start, table_size, stride_words, buffer)
            }
            _ => gray_walk_partial(
                b,
                row_start,
                table_size,
                stride_words,
                tile_count,
                last_tile_words,
                buffer,
            ),
        }
    } else {
        build_gray_table_flat_v0(b, row_start, table_size, stride_words, buffer, xor);
    }
}

#[cfg(feature = "simd")]
#[inline]
fn gray_walk_stride16_simd(
    b: &BitMatrix,
    row_start: usize,
    table_size: usize,
    stride_words: usize,
    buffer: &mut [u64],
    xor16: fn(&mut [[u64; 8]; 2], &[u64]),
) {
    debug_assert_eq!(stride_words, 2 * B2_GRAY_TILE_WORDS);

    let mut acc = [[0u64; B2_GRAY_TILE_WORDS]; 2];
    buffer[..stride_words].fill(0);

    let mut prev_gray = 0usize;
    for i in 1..table_size {
        let curr_gray = i ^ (i >> 1);
        let diff = prev_gray ^ curr_gray;
        let bit_pos = diff.trailing_zeros() as usize;

        let abs_row = row_start + bit_pos;
        if abs_row < b.rows() {
            xor16(&mut acc, b.row_words(abs_row));
        }

        let entry_start = curr_gray * stride_words;
        buffer[entry_start..entry_start + B2_GRAY_TILE_WORDS].copy_from_slice(&acc[0]);
        buffer[entry_start + B2_GRAY_TILE_WORDS..entry_start + stride_words]
            .copy_from_slice(&acc[1]);

        prev_gray = curr_gray;
    }
}

#[inline]
fn gray_walk_full<const TILES: usize>(
    b: &BitMatrix,
    row_start: usize,
    table_size: usize,
    stride_words: usize,
    buffer: &mut [u64],
) {
    debug_assert_eq!(stride_words, TILES * B2_GRAY_TILE_WORDS);

    let mut acc = [[0u64; B2_GRAY_TILE_WORDS]; TILES];
    buffer[..stride_words].fill(0);

    let mut prev_gray = 0usize;
    for i in 1..table_size {
        let curr_gray = i ^ (i >> 1);
        let diff = prev_gray ^ curr_gray;
        let bit_pos = diff.trailing_zeros() as usize;

        let abs_row = row_start + bit_pos;
        if abs_row < b.rows() {
            let row_words = b.row_words(abs_row);
            for (t, tile_acc) in acc.iter_mut().enumerate().take(TILES) {
                let base = t * B2_GRAY_TILE_WORDS;
                let src = &row_words[base..base + B2_GRAY_TILE_WORDS];
                tile_acc[0] ^= src[0];
                tile_acc[1] ^= src[1];
                tile_acc[2] ^= src[2];
                tile_acc[3] ^= src[3];
                tile_acc[4] ^= src[4];
                tile_acc[5] ^= src[5];
                tile_acc[6] ^= src[6];
                tile_acc[7] ^= src[7];
            }
        }

        let entry_start = curr_gray * stride_words;
        for (t, tile_acc) in acc.iter().enumerate().take(TILES) {
            let base = entry_start + t * B2_GRAY_TILE_WORDS;
            buffer[base..base + B2_GRAY_TILE_WORDS].copy_from_slice(tile_acc);
        }

        prev_gray = curr_gray;
    }
}

#[inline]
#[allow(clippy::too_many_arguments)]
fn gray_walk_partial(
    b: &BitMatrix,
    row_start: usize,
    table_size: usize,
    stride_words: usize,
    tile_count: usize,
    last_tile_words: usize,
    buffer: &mut [u64],
) {
    debug_assert!(tile_count > 0 && tile_count <= B2_GRAY_MAX_TILES);
    debug_assert!((1..=B2_GRAY_TILE_WORDS).contains(&last_tile_words));

    let mut acc = [[0u64; B2_GRAY_TILE_WORDS]; B2_GRAY_MAX_TILES];
    buffer[..stride_words].fill(0);

    let full_tiles = tile_count - 1;
    let mut prev_gray = 0usize;
    for i in 1..table_size {
        let curr_gray = i ^ (i >> 1);
        let diff = prev_gray ^ curr_gray;
        let bit_pos = diff.trailing_zeros() as usize;

        let abs_row = row_start + bit_pos;
        if abs_row < b.rows() {
            let row_words = b.row_words(abs_row);
            for (t, tile_acc) in acc.iter_mut().take(full_tiles).enumerate() {
                let base = t * B2_GRAY_TILE_WORDS;
                let src = &row_words[base..base + B2_GRAY_TILE_WORDS];
                for w in 0..B2_GRAY_TILE_WORDS {
                    tile_acc[w] ^= src[w];
                }
            }

            let last_base = full_tiles * B2_GRAY_TILE_WORDS;
            let src = &row_words[last_base..last_base + last_tile_words];
            for (dst, &src) in acc[full_tiles][..last_tile_words].iter_mut().zip(src) {
                *dst ^= src;
            }
        }

        let entry_start = curr_gray * stride_words;
        for (t, tile_acc) in acc.iter().take(full_tiles).enumerate() {
            let base = entry_start + t * B2_GRAY_TILE_WORDS;
            buffer[base..base + B2_GRAY_TILE_WORDS].copy_from_slice(tile_acc);
        }

        let last_base = entry_start + full_tiles * B2_GRAY_TILE_WORDS;
        buffer[last_base..last_base + last_tile_words]
            .copy_from_slice(&acc[full_tiles][..last_tile_words]);

        prev_gray = curr_gray;
    }
}

fn build_gray_table_flat_v0(
    b: &BitMatrix,
    row_start: usize,
    table_size: usize,
    stride_words: usize,
    buffer: &mut [u64],
    xor: XorInplaceFn,
) {
    let mut current = vec![0u64; stride_words];
    let mut prev_gray = 0usize;

    buffer[..stride_words].fill(0);

    for i in 1..table_size {
        let curr_gray = i ^ (i >> 1);

        let diff = prev_gray ^ curr_gray;
        let bit_pos = diff.trailing_zeros() as usize;

        if row_start + bit_pos < b.rows() {
            let row_words = b.row_words(row_start + bit_pos);
            xor(&mut current, row_words);
        }

        let entry_start = curr_gray * stride_words;
        buffer[entry_start..entry_start + stride_words].copy_from_slice(&current);

        prev_gray = curr_gray;
    }
}

/// Extracts k_block consecutive bits from a bit-packed row starting at column col_start.
///
/// Returns an index into the Gray code table (0..2^k_block).
fn extract_bits_from_row_words(row_words: &[u64], col_start: usize, k_block: usize) -> usize {
    debug_assert!(k_block <= usize::BITS as usize);

    if k_block == 0 {
        return 0;
    }

    let word_idx = col_start >> 6;
    let bit_offset = col_start & 63;
    let mut bits = row_words.get(word_idx).copied().unwrap_or(0) >> bit_offset;

    if bit_offset + k_block > 64 {
        bits |= row_words.get(word_idx + 1).copied().unwrap_or(0) << (64 - bit_offset);
    }

    let mask = if k_block == 64 {
        u64::MAX
    } else {
        (1u64 << k_block) - 1
    };
    (bits & mask) as usize
}

/// Multiplies two matrices over GF(2) using the M4RM algorithm.
///
/// Computes C = A × B where A is m×k and B is k×n, producing C which is m×n.
/// All arithmetic is performed over GF(2) (binary field).
///
/// # Arguments
///
/// * `a` - Left matrix (m × k)
/// * `b` - Right matrix (k × n)
///
/// # Returns
///
/// Result matrix C = A × B (m × n)
///
/// # Panics
///
/// Panics if the number of columns in A doesn't match the number of rows in B.
///
/// # Examples
///
/// ```
/// use gf2_core::matrix::BitMatrix;
/// use gf2_core::alg::m4rm::multiply;
///
/// let a = BitMatrix::identity(3);
/// let mut b = BitMatrix::zeros(3, 4);
/// b.set(0, 1, true);
/// b.set(1, 2, true);
///
/// let c = multiply(&a, &b);
/// assert_eq!(c.rows(), 3);
/// assert_eq!(c.cols(), 4);
/// assert_eq!(c.get(0, 1), true);
/// ```
pub fn multiply(a: &BitMatrix, b: &BitMatrix) -> BitMatrix {
    let m = a.rows();
    let k = a.cols();
    let n = b.cols();

    assert_eq!(
        k,
        b.rows(),
        "incompatible dimensions: A is {}×{} but B is {}×{}",
        m,
        k,
        b.rows(),
        n
    );

    if m == 0 || k == 0 || n == 0 {
        return BitMatrix::zeros(m, n);
    }

    // The one profile read of a multiplication: the resolved family feeds both
    // the schedule route and the register-tiled C-update gate below.
    let tuning = crate::tuning::active();
    let m4rm = tuning.m4rm();
    let route = m4rm_schedule_route_resolved(m4rm, k, n);
    let result = multiply_with_k_block(a, b, route.panel_width(), m4rm.tiled_min_stride_words());
    #[cfg(any(test, feature = "test-support"))]
    record_m4rm_effective_schedule(route, m4rm_tiled_effective_observation());
    result
}

fn multiply_with_k_block(
    a: &BitMatrix,
    b: &BitMatrix,
    k_block: usize,
    tiled_min_stride_words: usize,
) -> BitMatrix {
    let m = a.rows();
    let k = a.cols();
    let n = b.cols();

    if m == 0 || k == 0 || n == 0 {
        return BitMatrix::zeros(m, n);
    }

    let stride_words = n.div_ceil(64);
    let xor = resolve_xor_inplace(stride_words);

    if k_block == 1 {
        return a.mul_row_xor_dispatch(b);
    }

    if use_register_tiled_schedule(tiled_min_stride_words, m, stride_words) {
        if let Some(tile8xn) = resolve_m4rm_tile8xn() {
            #[cfg(any(test, feature = "test-support"))]
            record_m4rm_tiled_effective_observation(M4rmTiledEffectiveObservation::RegisterTiled);
            return multiply_register_tiled(a, b, k_block, stride_words, xor, tile8xn);
        }
    }

    #[cfg(any(test, feature = "test-support"))]
    record_m4rm_tiled_effective_observation(M4rmTiledEffectiveObservation::RowWise);
    multiply_rowwise_panels(a, b, k_block, stride_words, xor)
}

/// Multiplies two matrices with an experimental M4RI-style table schedule.
///
/// This is a test-support harness, not the production M4RM schedule-selection
/// policy. It is intended to stay bit-exact with [`multiply`] while tests and
/// benchmarks vary the Gray-table byte budget and maximum panel width.
///
/// # Arguments
///
/// * `a` - Left-hand matrix with dimensions `m × k`.
/// * `b` - Right-hand matrix with dimensions `k × n`.
/// * `target_table_bytes` - Preferred byte budget for one Gray-code table panel;
///   if no nonzero panel width fits, the helper falls back to `k_block = 1`.
/// * `max_k_block` - Maximum candidate panel width in bits. Oversized values
///   are safely ignored when the implied table would exceed the byte budget.
///
/// The two arguments replace the profile's table budgets and panel-width
/// ceilings for this call; the register-tiled C-update gate still follows
/// `m4rm.tiled_min_stride_words()` in the active
/// [`crate::tuning::CoreTuning`], resolved once here.
///
/// # Panics
///
/// Panics if `a.cols() != b.rows()`, if `target_table_bytes` is zero, or if
/// `max_k_block` is zero.
#[doc(hidden)]
#[cfg(any(test, feature = "test-support"))]
pub fn multiply_with_table_schedule_for_test(
    a: &BitMatrix,
    b: &BitMatrix,
    target_table_bytes: usize,
    max_k_block: usize,
) -> BitMatrix {
    let m = a.rows();
    let k = a.cols();
    let n = b.cols();

    assert_eq!(
        k,
        b.rows(),
        "incompatible dimensions: A is {}×{} but B is {}×{}",
        m,
        k,
        b.rows(),
        n
    );
    assert!(
        target_table_bytes > 0,
        "target_table_bytes must be positive"
    );
    assert!(max_k_block > 0, "max_k_block must be positive");

    let k_block = choose_k_block_with_limit(k, n, target_table_bytes, max_k_block);
    multiply_with_k_block(
        a,
        b,
        k_block,
        crate::tuning::active().m4rm().tiled_min_stride_words(),
    )
}
#[doc(hidden)]
#[cfg(any(test, feature = "test-support"))]
pub fn multiply_rowwise_for_test(a: &BitMatrix, b: &BitMatrix) -> BitMatrix {
    let k = a.cols();
    let n = b.cols();
    assert_eq!(
        k,
        b.rows(),
        "incompatible dimensions: A is {}×{} but B is {}×{}",
        a.rows(),
        k,
        b.rows(),
        n
    );

    if a.rows() == 0 || k == 0 || n == 0 {
        return BitMatrix::zeros(a.rows(), n);
    }

    let k_block = choose_k_block(crate::tuning::active().m4rm(), k, n);
    if k_block == 1 {
        return a.mul_row_xor_dispatch(b);
    }

    let stride_words = n.div_ceil(64);
    let xor = resolve_xor_inplace(stride_words);
    multiply_rowwise_panels(a, b, k_block, stride_words, xor)
}

/// Reports whether the register-tiled C-update schedule applies, against an
/// already-resolved `tiled_min_stride_words`.
///
/// The row count is kernel shape ([`M4RM_TILE_ROWS`] full rows per tile); the
/// stride bound is `m4rm.tiled_min_stride_words()` from the active
/// [`crate::tuning::CoreTuning`], resolved once per multiplication by
/// [`multiply`] and compared by [`stride_admits_tiled_schedule`], which is also
/// what [`M4rmScheduleRoute::tiled_stride_admitted`] reports.
#[inline]
fn use_register_tiled_schedule(
    tiled_min_stride_words: usize,
    m: usize,
    stride_words: usize,
) -> bool {
    m >= M4RM_TILE_ROWS && stride_admits_tiled_schedule(tiled_min_stride_words, stride_words)
}

/// Compares a row stride against an already-resolved `tiled_min_stride_words`.
///
/// One comparison serves both the dispatcher's predicate and the route
/// reporter, so neither can drift from the other.
#[inline]
fn stride_admits_tiled_schedule(tiled_min_stride_words: usize, stride_words: usize) -> bool {
    stride_words >= tiled_min_stride_words
}

#[inline]
fn resolve_m4rm_tile8xn() -> Option<M4rmTile8xNFn> {
    #[cfg(feature = "simd")]
    {
        crate::simd::maybe_simd().map(|backend| backend.m4rm_tile8xn_fn)
    }
    #[cfg(not(feature = "simd"))]
    {
        None
    }
}

fn multiply_rowwise_panels(
    a: &BitMatrix,
    b: &BitMatrix,
    k_block: usize,
    stride_words: usize,
    xor: XorInplaceFn,
) -> BitMatrix {
    let m = a.rows();
    let k = a.cols();
    let n = b.cols();
    let table_size = 1usize << k_block;
    let mut c = BitMatrix::zeros(m, n);

    // Pre-allocate flat buffer for Gray code table (reused across all panels).
    let mut table_buffer = vec![0u64; table_size * stride_words];

    let mut panel_start = 0;
    while panel_start < k {
        let panel_size = k_block.min(k - panel_start);
        build_gray_table_flat(b, panel_start, panel_size, n, &mut table_buffer, xor);
        update_panel_rowwise(
            a,
            &mut c,
            panel_start,
            panel_size,
            &table_buffer,
            stride_words,
            xor,
        );
        panel_start += k_block;
    }

    c
}

fn multiply_register_tiled(
    a: &BitMatrix,
    b: &BitMatrix,
    k_block: usize,
    stride_words: usize,
    xor: XorInplaceFn,
    tile8xn: M4rmTile8xNFn,
) -> BitMatrix {
    let m = a.rows();
    let k = a.cols();
    let n = b.cols();
    let table_size = 1usize << k_block;
    let mut c = BitMatrix::zeros(m, n);
    let mut table_buffer = vec![0u64; table_size * stride_words];

    let mut panel_start = 0usize;
    while panel_start < k {
        let panel_size = k_block.min(k - panel_start);
        build_gray_table_flat(b, panel_start, panel_size, n, &mut table_buffer, xor);
        update_panel_register_tiled(
            a,
            &mut c,
            panel_start,
            panel_size,
            &table_buffer,
            stride_words,
            xor,
            tile8xn,
        );
        panel_start += k_block;
    }

    c
}

fn update_panel_rowwise(
    a: &BitMatrix,
    c: &mut BitMatrix,
    panel_start: usize,
    panel_size: usize,
    table_buffer: &[u64],
    stride_words: usize,
    xor: XorInplaceFn,
) {
    for i in 0..a.rows() {
        let idx = extract_bits_from_row_words(a.row_words(i), panel_start, panel_size);
        let entry_start = idx * stride_words;
        let table_entry = &table_buffer[entry_start..entry_start + stride_words];
        xor(c.row_words_mut(i), table_entry);
    }
}

#[inline(never)]
#[allow(clippy::too_many_arguments)]
fn update_panel_register_tiled(
    a: &BitMatrix,
    c: &mut BitMatrix,
    panel_start: usize,
    panel_size: usize,
    table_buffer: &[u64],
    stride_words: usize,
    xor: XorInplaceFn,
    tile8xn: M4rmTile8xNFn,
) {
    let full_rows = a.rows() / M4RM_TILE_ROWS * M4RM_TILE_ROWS;

    for row_start in (0..full_rows).step_by(M4RM_TILE_ROWS) {
        let idx = row_tile_indices::<M4RM_TILE_ROWS>(a, row_start, panel_start, panel_size);

        let c_block = c.row_words_block_mut(row_start, M4RM_TILE_ROWS);
        tile8xn(c_block, stride_words, table_buffer, &idx);

        let full_words = stride_words / M4RM_TILE_WORDS * M4RM_TILE_WORDS;
        if full_words < stride_words {
            update_row_tile_tail(c, row_start, full_words, stride_words, table_buffer, &idx);
        }
    }

    for row in full_rows..a.rows() {
        let idx = extract_bits_from_row_words(a.row_words(row), panel_start, panel_size);
        let entry_start = idx * stride_words;
        let table_entry = &table_buffer[entry_start..entry_start + stride_words];
        xor(c.row_words_mut(row), table_entry);
    }
}

#[inline(always)]
fn row_tile_indices<const ROWS: usize>(
    a: &BitMatrix,
    row_start: usize,
    panel_start: usize,
    panel_size: usize,
) -> [usize; ROWS] {
    core::array::from_fn(|r| {
        extract_bits_from_row_words(a.row_words(row_start + r), panel_start, panel_size)
    })
}

#[cfg(test)]
#[inline(never)]
fn xor_tile8xn_scalar_block(
    c_block: &mut [u64],
    stride_words: usize,
    table_buffer: &[u64],
    idx: &[usize; M4RM_TILE_ROWS],
) {
    let mut word_start = 0usize;
    while word_start + M4RM_TILE_WORDS <= stride_words {
        xor_tile8x4_scalar_block(c_block, stride_words, word_start, table_buffer, idx);
        word_start += M4RM_TILE_WORDS;
    }
}

#[cfg(test)]
#[inline(never)]
fn xor_tile8x4_scalar_block(
    c_block: &mut [u64],
    stride_words: usize,
    word_start: usize,
    table_buffer: &[u64],
    idx: &[usize; M4RM_TILE_ROWS],
) {
    let mut acc0 = load_block4(c_block, stride_words, 0, word_start);
    let mut acc1 = load_block4(c_block, stride_words, 1, word_start);
    let mut acc2 = load_block4(c_block, stride_words, 2, word_start);
    let mut acc3 = load_block4(c_block, stride_words, 3, word_start);
    let mut acc4 = load_block4(c_block, stride_words, 4, word_start);
    let mut acc5 = load_block4(c_block, stride_words, 5, word_start);
    let mut acc6 = load_block4(c_block, stride_words, 6, word_start);
    let mut acc7 = load_block4(c_block, stride_words, 7, word_start);

    xor_acc4(
        &mut acc0,
        table_entry4(table_buffer, stride_words, idx[0], word_start),
    );
    xor_acc4(
        &mut acc1,
        table_entry4(table_buffer, stride_words, idx[1], word_start),
    );
    xor_acc4(
        &mut acc2,
        table_entry4(table_buffer, stride_words, idx[2], word_start),
    );
    xor_acc4(
        &mut acc3,
        table_entry4(table_buffer, stride_words, idx[3], word_start),
    );
    xor_acc4(
        &mut acc4,
        table_entry4(table_buffer, stride_words, idx[4], word_start),
    );
    xor_acc4(
        &mut acc5,
        table_entry4(table_buffer, stride_words, idx[5], word_start),
    );
    xor_acc4(
        &mut acc6,
        table_entry4(table_buffer, stride_words, idx[6], word_start),
    );
    xor_acc4(
        &mut acc7,
        table_entry4(table_buffer, stride_words, idx[7], word_start),
    );

    store_block4(c_block, stride_words, 0, word_start, acc0);
    store_block4(c_block, stride_words, 1, word_start, acc1);
    store_block4(c_block, stride_words, 2, word_start, acc2);
    store_block4(c_block, stride_words, 3, word_start, acc3);
    store_block4(c_block, stride_words, 4, word_start, acc4);
    store_block4(c_block, stride_words, 5, word_start, acc5);
    store_block4(c_block, stride_words, 6, word_start, acc6);
    store_block4(c_block, stride_words, 7, word_start, acc7);
}

#[cfg(test)]
#[inline(always)]
fn table_entry4(
    table_buffer: &[u64],
    stride_words: usize,
    idx: usize,
    word_start: usize,
) -> &[u64] {
    let start = idx * stride_words + word_start;
    &table_buffer[start..start + M4RM_TILE_WORDS]
}

#[cfg(test)]
#[inline(always)]
fn load_block4(
    c_block: &[u64],
    stride_words: usize,
    row: usize,
    word_start: usize,
) -> [u64; M4RM_TILE_WORDS] {
    let start = row * stride_words + word_start;
    [
        c_block[start],
        c_block[start + 1],
        c_block[start + 2],
        c_block[start + 3],
    ]
}

#[cfg(test)]
#[inline(always)]
fn store_block4(
    c_block: &mut [u64],
    stride_words: usize,
    row: usize,
    word_start: usize,
    acc: [u64; M4RM_TILE_WORDS],
) {
    let start = row * stride_words + word_start;
    c_block[start..start + M4RM_TILE_WORDS].copy_from_slice(&acc);
}

#[cfg(test)]
#[inline(always)]
fn xor_acc4(acc: &mut [u64; M4RM_TILE_WORDS], src: &[u64]) {
    acc[0] ^= src[0];
    acc[1] ^= src[1];
    acc[2] ^= src[2];
    acc[3] ^= src[3];
}

#[allow(clippy::too_many_arguments)]
fn update_row_tile_tail(
    c: &mut BitMatrix,
    row_start: usize,
    word_start: usize,
    stride_words: usize,
    table_buffer: &[u64],
    idx: &[usize; M4RM_TILE_ROWS],
) {
    for r in 0..M4RM_TILE_ROWS {
        let start = idx[r] * stride_words + word_start;
        let table_entry = &table_buffer[start..idx[r] * stride_words + stride_words];
        let c_tail = &mut c.row_words_mut(row_start + r)[word_start..stride_words];
        for (dst, &src) in c_tail.iter_mut().zip(table_entry) {
            *dst ^= src;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernels::ops::xor_inplace;

    /// The M4RM selector family of the active profile. No lib test installs a
    /// profile, so every case below runs on the conservative table.
    fn conservative_m4rm() -> &'static M4rmSelectors {
        crate::tuning::CoreTuning::CONSERVATIVE.m4rm()
    }

    #[test]
    fn test_choose_k_block() {
        // Small dimensions use the L1-resident cost-balance heuristic
        // (~0.8·log2(min(k, n))): n=100 → round(0.8·6.64) = 5.
        let k1 = choose_k_block(conservative_m4rm(), 100, 100);
        assert!((4..=6).contains(&k1));

        // Very large output width still resolves to a valid panel.
        let k2 = choose_k_block(conservative_m4rm(), 100, 10000);
        assert!(k2 >= 1);
    }

    #[test]
    fn test_choose_k_block_small_n_heuristic() {
        // Reproduces the measured per-size optima from
        // 2026-05-28-bdf60780-matmul-gf2-smalln.md: small k at n=64,
        // wider panels at n=256, none above the small-n cap.
        let small_n_max_k = conservative_m4rm().small_n_max_k();
        assert_eq!(choose_k_block(conservative_m4rm(), 64, 64), 5);
        assert_eq!(choose_k_block(conservative_m4rm(), 128, 128), 6);
        assert_eq!(choose_k_block(conservative_m4rm(), 256, 256), 6);
        assert_eq!(choose_k_block(conservative_m4rm(), 512, 512), 7);
        // Lower clamp keeps the panel width at >= 2 (k=1 degenerates to row-XOR).
        assert_eq!(choose_k_block_small_n(small_n_max_k, 3, 256), 2);
        // k=1 inner dim maps to the row-XOR path (k_block == 1).
        assert_eq!(choose_k_block_small_n(small_n_max_k, 1, 256), 1);
        assert_eq!(choose_k_block_small_n(small_n_max_k, 0, 256), 0);
        // Never exceeds the small-n cap even for very wide inner dims.
        assert!(choose_k_block_small_n(small_n_max_k, 100_000, 512) <= M4RM_SMALL_N_MAX_K);
    }

    #[test]
    fn test_production_schedule_policy_small_n_tier_and_wide_tier_boundary() {
        // Below the wide tier (stride_words < 16, i.e. n < 1024) the small-n
        // L1-resident heuristic governs; it routes through choose_k_block_small_n.
        // n <= 960 bits is at most 15 words (stride_words < 16) → small-n tier.
        let m4rm = conservative_m4rm();
        for n in [1, 63, 64, 65, 128, 129, 512, 960] {
            assert_eq!(
                choose_k_block(m4rm, 4096, n),
                choose_k_block_small_n(m4rm.small_n_max_k(), 4096, n),
                "n={n} should use the small-n heuristic"
            );
        }
        // n=961..1024 round up to 16 words and enter the wide tier.
        assert!(961usize.div_ceil(64) >= M4RM_WIDE_TIER_MIN_STRIDE_WORDS);

        // The n=0 degenerate case still resolves to 0.
        assert_eq!(choose_k_block(m4rm, 4096, 0), 0);

        // The wide tier (n >= 1024) is unchanged from the 8e305c21 / 974a85bd
        // production policy — these are the [hard] non-regression cells.
        assert_eq!(choose_k_block(m4rm, 4096, 1024), 9);
        assert_eq!(choose_k_block(m4rm, 4096, 2048), 9);
        assert_eq!(choose_k_block(m4rm, 4096, 4096), 9);
        assert_eq!(production_table_budget(m4rm, 16), M4RM_DEFAULT_TABLE_BYTES);
        assert_eq!(production_table_budget(m4rm, 32), M4RM_MID_TABLE_BYTES);
        assert_eq!(production_table_budget(m4rm, 64), M4RM_WIDE_TABLE_BYTES);
    }

    #[test]
    fn test_m4rm_schedule_route_reports_the_conservative_tier_boundary() {
        let m4rm = conservative_m4rm();
        let boundary = m4rm.wide_tier_min_stride_words();
        let n_below = (boundary - 1) * 64;
        let n_at = n_below + 1;

        assert_eq!(
            m4rm_schedule_route(4096, n_below).tier(),
            M4rmScheduleTier::SmallN
        );
        assert_eq!(
            m4rm_schedule_route(4096, n_at).tier(),
            M4rmScheduleTier::Wide
        );
        // The tier does not turn over again above the boundary.
        assert_eq!(
            m4rm_schedule_route(4096, boundary * 64 * 4).tier(),
            M4rmScheduleTier::Wide
        );
    }

    #[test]
    fn test_m4rm_schedule_route_reports_the_dispatched_panel_width() {
        let m4rm = conservative_m4rm();
        for (k, n) in [(4096, 64), (4096, 512), (4096, 1024), (4096, 4096), (1, 1)] {
            let route = m4rm_schedule_route(k, n);
            assert_eq!(
                route.panel_width(),
                choose_k_block(m4rm, k, n),
                "route and dispatcher disagree at k={k}, n={n}"
            );
            match route.tier() {
                M4rmScheduleTier::SmallN => assert!(route.panel_width() <= m4rm.small_n_max_k()),
                M4rmScheduleTier::Wide => assert!(route.panel_width() <= m4rm.wide_max_k()),
            }
        }
    }

    #[test]
    fn test_m4rm_schedule_route_reports_the_tiled_stride_gate() {
        let m4rm = conservative_m4rm();
        let tiled_min = m4rm.tiled_min_stride_words();
        let n_below = (tiled_min - 1) * 64;
        let n_at = n_below + 1;

        assert!(!m4rm_schedule_route(4096, n_below).tiled_stride_admitted());
        assert!(m4rm_schedule_route(4096, n_at).tiled_stride_admitted());

        // The reported gate is the stride half of the predicate the dispatcher
        // calls, so it agrees with it at every width once the row count admits
        // a full tile.
        for n in [n_below, n_at, 4096, 0] {
            let stride_words = row_stride_words(n);
            assert_eq!(
                m4rm_schedule_route(4096, n).tiled_stride_admitted(),
                use_register_tiled_schedule(tiled_min, M4RM_TILE_ROWS, stride_words),
                "reported gate disagrees with the dispatcher's predicate at n={n}"
            );
        }

        // The row half is kernel shape and outside what the reporter observes:
        // too few rows leave the tile unusable at an admitted stride.
        let stride_words = row_stride_words(n_at);
        assert!(m4rm_schedule_route(4096, n_at).tiled_stride_admitted());
        assert!(!use_register_tiled_schedule(
            tiled_min,
            M4RM_TILE_ROWS - 1,
            stride_words
        ));
    }

    #[test]
    fn test_m4ri_style_schedule_selects_wider_panels_when_cache_budget_allows() {
        assert_eq!(choose_k_block_with_limit(4096, 4096, 64 * 1024, 8), 7);
        assert_eq!(choose_k_block_with_limit(4096, 4096, 128 * 1024, 10), 8);
        assert_eq!(choose_k_block_with_limit(4096, 4096, 256 * 1024, 10), 9);
        assert_eq!(choose_k_block_with_limit(4096, 4096, 512 * 1024, 10), 10);
    }

    #[test]
    fn test_m4ri_style_schedule_rejects_overflow_impossible_panel_width() {
        let selected = choose_k_block_with_limit(
            usize::BITS as usize - 1,
            1,
            usize::MAX,
            usize::BITS as usize - 1,
        );
        let bytes_per_entry = 8;
        let max_table_entries = usize::MAX / bytes_per_entry;

        assert_eq!(selected, usize::BITS as usize - 4);
        assert!((1usize << selected) <= max_table_entries);
        assert!((1usize << (selected + 1)) > max_table_entries);
    }

    #[test]
    fn test_extract_bits() {
        let mut a = BitMatrix::zeros(1, 8);
        a.set(0, 1, true);
        a.set(0, 3, true);

        // Extract bits 0-3: should get binary 1010 = 10
        let bits = extract_bits_from_row_words(a.row_words(0), 0, 4);
        assert_eq!(bits, 0b1010);
    }

    #[test]
    fn test_extract_bits_crosses_word_boundary() {
        let mut a = BitMatrix::zeros(1, 130);
        a.set(0, 63, true);
        a.set(0, 64, true);
        a.set(0, 66, true);

        let bits = extract_bits_from_row_words(a.row_words(0), 63, 5);
        assert_eq!(bits, 0b01011);
    }

    #[test]
    fn test_multiply_identity() {
        let a = BitMatrix::identity(4);
        let b = BitMatrix::identity(4);
        let c = multiply(&a, &b);

        // I × I = I
        for i in 0..4 {
            for j in 0..4 {
                assert_eq!(c.get(i, j), i == j);
            }
        }
    }

    #[test]
    fn test_multiply_simple() {
        let mut a = BitMatrix::zeros(2, 2);
        a.set(0, 0, true);
        a.set(1, 1, true);

        let mut b = BitMatrix::zeros(2, 2);
        b.set(0, 1, true);
        b.set(1, 0, true);

        let c = multiply(&a, &b);

        assert!(c.get(0, 1));
        assert!(c.get(1, 0));
        assert!(!c.get(0, 0));
        assert!(!c.get(1, 1));
    }

    #[test]
    fn test_gray_code_table_correctness() {
        // Verify Gray code table generates correct linear combinations
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        let mut rng = StdRng::seed_from_u64(42);
        let mut b = BitMatrix::zeros(8, 64);
        for r in 0..8 {
            for c in 0..64 {
                if rng.gen_bool(0.5) {
                    b.set(r, c, true);
                }
            }
        }

        let table = build_gray_table(&b, 0, 8, 64);

        // Verify each table entry is correct XOR of indicated rows
        for (idx, entry) in table.iter().enumerate().take(256) {
            let mut expected = vec![0u64; 1];
            for bit in 0..8 {
                if (idx & (1 << bit)) != 0 {
                    let row_words = b.row_words(bit);
                    xor_inplace(&mut expected, row_words);
                }
            }

            assert_eq!(&entry[..], &expected[..], "Table entry {} mismatch", idx);
        }
    }

    #[test]
    fn test_flat_buffer_equivalence() {
        // Verify flat buffer version produces same results as Vec<Vec<>>
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        let mut rng = StdRng::seed_from_u64(123);
        let mut b = BitMatrix::zeros(8, 128);
        for r in 0..8 {
            for c in 0..128 {
                if rng.gen_bool(0.5) {
                    b.set(r, c, true);
                }
            }
        }

        // Generate with original version
        let table_vec = build_gray_table(&b, 0, 8, 128);

        // Generate with flat buffer version
        let table_size = 256;
        let stride_words = 128_usize.div_ceil(64);
        let mut table_flat = vec![0u64; table_size * stride_words];
        let xor = resolve_xor_inplace(stride_words);
        build_gray_table_flat(&b, 0, 8, 128, &mut table_flat, xor);

        // Compare all entries
        for (idx, vec_entry) in table_vec.iter().enumerate() {
            let entry_start = idx * stride_words;
            let entry_end = entry_start + stride_words;
            let flat_entry = &table_flat[entry_start..entry_end];

            assert_eq!(
                flat_entry,
                &vec_entry[..],
                "Entry {} mismatch between flat and Vec<Vec<>> versions",
                idx
            );
        }
    }

    #[test]
    fn test_register_tiled_schedule_threshold_preserves_small_sizes() {
        let tiled_min = conservative_m4rm().tiled_min_stride_words();
        // Fewer than 8 rows: no full row tile, stay on row-XOR.
        assert!(!use_register_tiled_schedule(tiled_min, 7, 16));
        assert!(!use_register_tiled_schedule(tiled_min, 7, 4));
        // Strides 1..=3 have no full 4-word tile → row-XOR.
        assert!(!use_register_tiled_schedule(tiled_min, 64, 1));
        assert!(!use_register_tiled_schedule(tiled_min, 64, 2));
        assert!(!use_register_tiled_schedule(tiled_min, 64, 3));
        // jit:bdf60780: the tile gate is lowered to stride_words >= 4 so that
        // n=256 (stride 4) and n=512 (stride 8) reach the SIMD 8×4 tile.
        assert!(use_register_tiled_schedule(tiled_min, 64, 4));
        assert!(use_register_tiled_schedule(tiled_min, 64, 8));
        assert!(use_register_tiled_schedule(tiled_min, 8, 16));
        assert!(use_register_tiled_schedule(tiled_min, 8, 32));
    }

    #[test]
    fn test_register_tiled_multiply_matches_naive_with_wide_remainders() {
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        let mut rng = StdRng::seed_from_u64(0x19bc_3199);
        let (m, k, n) = (9, 17, 2048);
        let mut a = BitMatrix::zeros(m, k);
        let mut b = BitMatrix::zeros(k, n);

        for r in 0..m {
            for c in 0..k {
                if rng.gen_bool(0.5) {
                    a.set(r, c, true);
                }
            }
        }
        for r in 0..k {
            for c in 0..n {
                if rng.gen_bool(0.5) {
                    b.set(r, c, true);
                }
            }
        }

        let k_block = choose_k_block(conservative_m4rm(), k, n);
        let stride_words = n.div_ceil(64);
        let xor = resolve_xor_inplace(stride_words);
        let tiled =
            multiply_register_tiled(&a, &b, k_block, stride_words, xor, xor_tile8xn_scalar_block);

        for r in 0..m {
            for c in 0..n {
                let expected = (0..k).fold(false, |acc, kk| acc ^ (a.get(r, kk) && b.get(kk, c)));
                assert_eq!(
                    tiled.get(r, c),
                    expected,
                    "register-tiled mismatch at ({r}, {c})"
                );
            }
        }
    }

    #[test]
    fn test_multiply_with_flat_buffer() {
        // End-to-end test that flat buffer version produces correct results
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        let mut rng = StdRng::seed_from_u64(456);

        // Test various sizes
        for size in [64, 128, 256] {
            let mut a = BitMatrix::zeros(size, size);
            let mut b = BitMatrix::zeros(size, size);

            for r in 0..size {
                for c in 0..size {
                    if rng.gen_bool(0.5) {
                        a.set(r, c, true);
                    }
                    if rng.gen_bool(0.5) {
                        b.set(r, c, true);
                    }
                }
            }

            let c = multiply(&a, &b);

            // Verify result dimensions
            assert_eq!(c.rows(), size);
            assert_eq!(c.cols(), size);

            // Verify a few spot checks with naive multiplication
            for i in 0..size.min(10) {
                for j in 0..size.min(10) {
                    let mut expected = false;
                    for k in 0..size {
                        if a.get(i, k) && b.get(k, j) {
                            expected = !expected; // XOR in GF(2)
                        }
                    }
                    assert_eq!(
                        c.get(i, j),
                        expected,
                        "Mismatch at ({}, {}) for size {}",
                        i,
                        j,
                        size
                    );
                }
            }
        }
    }

    #[test]
    fn test_m4ri_style_schedule_matches_production_on_boundary_shapes() {
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        fn random_matrix(rows: usize, cols: usize, rng: &mut StdRng) -> BitMatrix {
            let mut matrix = BitMatrix::zeros(rows, cols);
            for r in 0..rows {
                for c in 0..cols {
                    if rng.gen_bool(0.5) {
                        matrix.set(r, c, true);
                    }
                }
            }
            matrix
        }

        let mut rng = StdRng::seed_from_u64(0x380e_041a);
        for (m, k, n) in [
            (0, 13, 65),
            (1, 1, 1),
            (7, 63, 64),
            (8, 64, 65),
            (9, 65, 129),
            (16, 257, 512),
        ] {
            let a = random_matrix(m, k, &mut rng);
            let b = random_matrix(k, n, &mut rng);

            let production = multiply(&a, &b);
            let wider_gray_table = multiply_with_table_schedule_for_test(&a, &b, 256 * 1024, 10);

            assert_eq!(
                wider_gray_table, production,
                "m4ri-style schedule mismatch for {m}×{k} times {k}×{n}"
            );
        }
    }

    #[test]
    fn test_production_multiply_matches_legacy_schedule_on_boundary_shapes() {
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        fn random_matrix(rows: usize, cols: usize, rng: &mut StdRng) -> BitMatrix {
            let mut matrix = BitMatrix::zeros(rows, cols);
            for r in 0..rows {
                for c in 0..cols {
                    if rng.gen_bool(0.5) {
                        matrix.set(r, c, true);
                    }
                }
            }
            matrix
        }

        let mut rng = StdRng::seed_from_u64(0x8e30_5c21);
        for (m, k, n) in [
            (0, 13, 65),
            (1, 1, 1),
            (7, 63, 64),
            (8, 64, 65),
            (9, 65, 129),
            (16, 128, 1024),
            (17, 129, 2048),
            (17, 129, 4096),
        ] {
            let a = random_matrix(m, k, &mut rng);
            let b = random_matrix(k, n, &mut rng);

            let production = multiply(&a, &b);
            let legacy_schedule = multiply_with_table_schedule_for_test(
                &a,
                &b,
                M4RM_DEFAULT_TABLE_BYTES,
                M4RM_DEFAULT_MAX_K,
            );

            assert_eq!(
                production, legacy_schedule,
                "production policy mismatch for {m}×{k} times {k}×{n}"
            );
        }
    }
}
