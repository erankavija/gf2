//! Deterministic linear-congruential pseudo-random generator used across
//! the workspace as the single source of truth for the "cheap
//! deterministic LCG" pattern.
//!
//! The implementation uses Numerical Recipes' `MMIX` constants
//! (multiplier `6_364_136_223_846_793_005`, increment
//! `1_442_695_040_888_963_407`). Consumers include:
//!
//! - production permutation generators (e.g. `gf2_coding::fading` for
//!   Rician-channel seed-reproducible Fisher-Yates shuffles),
//! - deterministic test/benchmark data in `gf2_core::gf2m`,
//!   `gf2_coding::gldpc`, `gf2_coding::modem`, and
//!   `gf2_kernels_simd::modem`,
//! - modem parity fixtures that need the same stream across CPU
//!   scalar, AVX2, and HIP backends so cross-backend failures
//!   reproduce deterministically.
//!
//! This is **not** a cryptographic RNG. It is a simulation-grade,
//! seed-reproducible PRNG. Use `rand`/`rand_chacha` for anything
//! security-sensitive.

/// Deterministic LCG state.
///
/// See the module documentation for the rationale for living in
/// `gf2-core` rather than in a downstream test-support module.
pub struct Lcg {
    state: u64,
}

impl Lcg {
    /// Constructs a new LCG seeded with `seed`.
    ///
    /// # Arguments
    ///
    /// * `seed` — 64-bit seed. Any value is valid; distinct seeds
    ///   produce independent streams.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let _ = Lcg::new(0);
    /// let _ = Lcg::new(u64::MAX);
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn new(seed: u64) -> Self {
        Self { state: seed }
    }

    /// Advances the state one step and returns the raw 64-bit output.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(1);
    /// let _ = rng.next_u64();
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_u64(&mut self) -> u64 {
        self.state = self
            .state
            .wrapping_mul(6_364_136_223_846_793_005)
            .wrapping_add(1_442_695_040_888_963_407);
        self.state
    }

    /// Advances the state and returns the top 32 bits of the new state.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(42);
    /// let _ = rng.next_u32();
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_u32(&mut self) -> u32 {
        (self.next_u64() >> 32) as u32
    }

    /// Returns a pseudo-uniform `f32` in the **closed** interval
    /// `[-1.0, 1.0]`. Both endpoints are reachable (when
    /// `next_u32() == 0` the output is `-1.0`; when
    /// `next_u32() == u32::MAX` the output is `1.0`).
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(7);
    /// assert!(rng.next_unit_f32().abs() <= 1.0);
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_unit_f32(&mut self) -> f32 {
        (self.next_u32() as f32 / u32::MAX as f32) * 2.0 - 1.0
    }

    /// Returns a pseudo-uniform `f64` in the **closed** interval
    /// `[-1.0, 1.0]`. Both endpoints are reachable (when
    /// `next_u32() == 0` the output is `-1.0`; when
    /// `next_u32() == u32::MAX` the output is `1.0`).
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(11);
    /// assert!(rng.next_unit_f64().abs() <= 1.0);
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_unit_f64(&mut self) -> f64 {
        (self.next_u32() as f64 / u32::MAX as f64) * 2.0 - 1.0
    }

    /// Returns a pseudo-uniform `f32` in the **closed** interval
    /// `[lo, hi]`. Both endpoints are reachable (when
    /// `next_u32() == 0` the output is `lo`; when
    /// `next_u32() == u32::MAX` the output is `hi`).
    ///
    /// # Arguments
    ///
    /// * `lo` — Lower bound, reachable.
    /// * `hi` — Upper bound, reachable; caller must ensure `hi > lo`.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(13);
    /// let v = rng.next_positive_f32(0.05, 2.0);
    /// assert!(v >= 0.05 && v <= 2.0);
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_positive_f32(&mut self, lo: f32, hi: f32) -> f32 {
        lo + (self.next_u32() as f32 / u32::MAX as f32) * (hi - lo)
    }

    /// Returns a pseudo-uniform `f64` in the **closed** interval
    /// `[lo, hi]`. Both endpoints are reachable (when
    /// `next_u32() == 0` the output is `lo`; when
    /// `next_u32() == u32::MAX` the output is `hi`).
    ///
    /// # Arguments
    ///
    /// * `lo` — Lower bound, reachable.
    /// * `hi` — Upper bound, reachable; caller must ensure `hi > lo`.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(17);
    /// let v = rng.next_positive_f64(0.05, 2.0);
    /// assert!(v >= 0.05 && v <= 2.0);
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_positive_f64(&mut self, lo: f64, hi: f64) -> f64 {
        lo + (self.next_u32() as f64 / u32::MAX as f64) * (hi - lo)
    }

    /// Returns a pseudo-uniform `usize` in `[0, n)`.
    ///
    /// # Arguments
    ///
    /// * `n` — Exclusive upper bound; caller must ensure `n > 0`.
    ///
    /// # Panics
    ///
    /// Panics (via integer `%`) if `n == 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use gf2_core::rng::Lcg;
    ///
    /// let mut rng = Lcg::new(19);
    /// assert!(rng.next_bounded_usize(8) < 8);
    /// ```
    ///
    /// # Complexity
    ///
    /// O(1).
    #[inline]
    pub fn next_bounded_usize(&mut self, n: usize) -> usize {
        (self.next_u64() as usize) % n
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_lcg_derived_methods_stay_in_range() {
        let mut rng = Lcg::new(42);

        // next_u32: must produce a value in the u32 range
        let _v = rng.next_u32();

        // next_unit_f32: in [-1.0, 1.0]
        let uf32 = rng.next_unit_f32();
        assert!((-1.0_f32..=1.0_f32).contains(&uf32));

        // next_unit_f64: in [-1.0, 1.0]
        let uf64 = rng.next_unit_f64();
        assert!((-1.0_f64..=1.0_f64).contains(&uf64));

        // next_positive_f32: in [lo, hi]
        let pf32 = rng.next_positive_f32(0.1, 0.9);
        assert!((0.1_f32..=0.9_f32).contains(&pf32));

        // next_positive_f64: in [lo, hi]
        let pf64 = rng.next_positive_f64(0.1, 0.9);
        assert!((0.1_f64..=0.9_f64).contains(&pf64));

        // next_bounded_usize: must be in [0, n)
        let bu = rng.next_bounded_usize(7);
        assert!(bu < 7);
    }
}
